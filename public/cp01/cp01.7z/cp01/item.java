public class item {
   private static int item = 0;
   private int max;
   public item(int val_item)
   {
   max=val_item;
   }
//processo de incremento de item
//item � a variavel compartilhada   
   public synchronized void inc()
   {   //atualiza��o do estado do thread
       prods_staus(" **Regi�o Critica**\n");
       
       //loops vazios para simular processamento, para podemos visualizar seu processamento
       loops(deposito.tempo2);
     
     // verifica��o do limite maximo definido do buffer        
     if (item<max) 
      {item++;
       
       //atualiza��o da janela do buffer
       deposito.output.append("Produtor :"+ Thread.currentThread().getName() +
         " Produziu Item : " + item +
         " Prioridade :" + Thread.currentThread().getPriority() + "\n" );
       deposito.status.setText(Integer.toString(item));  
       deposito.output.setCaretPosition(deposito.output.getText().length());
       //atualiza��o do estado do thread para n�o mostrar 2 processos na RC
       prods_staus(" Pronto\n");
       
       // acorda todos os threads a espera de entrar na RC
       notifyAll();
      }
      
      //bloqueia produtor se o buffer estiver no seu limite
      else
      { try
         {  
         prods_staus(" Bloqueado\n");
         wait();
	     }
         catch( InterruptedException e ) 
         {System.err.println( e.toString() );}
         }
   }

  //processo de decremento de item
  //item � a variavel compartilhada     
   public synchronized void dec()
   {
       //atualiza��o do estado do thread
      cons_staus(" **Regi�o Critica**\n");
       //loops vazios para simular processamento, para podemos visualizar seu processamento
      loops(deposito.tempo2);
      // verifica��o do limite minimo definido do buffer        
      if (item>0)
      {     //atualiza��o da janela do buffer
            deposito.output.append("Consumidor :"+ Thread.currentThread().getName() +
      		  " Consumiu item :"+ item +" Prioridade :" + Thread.currentThread().getPriority()+ "\n");
      		item--;
      		deposito.status.setText(Integer.toString(item)); 
      deposito.output.setCaretPosition(deposito.output.getText().length());
      
      //atualiza��o do estado do thread para n�o mostrar 2 processos na RC
      cons_staus("Pronto \n");
       // acorda todos os threads a espera de entrar na RC
      notifyAll();
       }
       //bloqueia consumidor se o buffer estiver no seu limite
       else
      {  try
         {  
         cons_staus(" Bloqueado\n");
         wait();
         }
       catch( InterruptedException e )
       {System.err.println( e.toString() );} 
       } 

   }
   
   private synchronized void prods_staus(String s)
      {
       //referencia para o thread atual
       produtor ref = (produtor)Thread.currentThread();
       //seta o estado do thread atual
       ref.stado="Produtor["+Thread.currentThread().getPriority()+"] : "+ Thread.currentThread().getName() + s;
       deposito.stado();
      }
   
   
    private synchronized void  cons_staus(String s)
      { 
      //referencia para o thread atual
      consumidor ref = (consumidor)Thread.currentThread();
      //seta o estado do thread atual
      ref.stado="Consumidor["+Thread.currentThread().getPriority()+"] : "+ Thread.currentThread().getName() + s;
      deposito.stado();
      }

   private void loops(int x)
  {
  	for (int nada=0; nada<(x*1000000); nada++);
    for (int nada=0; nada<(x*1000000); nada++);
  } 
}

