public class consumidor extends Thread {
 private item ref_item;
 public boolean morto;
 public String stado;
  //constructor
   public consumidor ( String f1,String f2,item i)
   {
      super( f1 );
      this.setPriority(Integer.parseInt(f2));
      ref_item=i;
   }
  //metodo run
   public void run()
   {//atualiza o estado do processo
  	 stado="Consumidor["+getPriority()+"] : "+ getName() +" Iniciado\n";
     deposito.stado();
     //loop de execu��o  
     while (!morto)
     { stado="Consumidor["+getPriority()+"] : "+ getName() +" Pronto\n";
       deposito.stado();
     //loop de processamento
       loops(deposito.tempo);
     //metodo de acesso a RC
       ref_item.dec();  
     
     //atualiza o estado  
       stado="Consumidor["+getPriority()+"] : "+ getName() +" Pronto\n";
       deposito.stado();
         
    }
     
      deposito.output.append("Consumidor["+getPriority()+"] : "+ getName() +" Morreu\n");
   }

   private void loops(int x)
  {
  	for (int nada=0; nada<(x*1000000); nada++);
    for (int nada=0; nada<(x*1000000); nada++);
  } 
 
 
 
}

