import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class deposito extends JFrame {

   private JLabel l1,l2,l3,l4;
   private JTextField pid,pprio,cid,cprio;
   private JButton Criap,Criac,Matap,Matac;
   private JPanel status_panel,imput_panel,area_panel;
   private Container c;
   private UIManager.LookAndFeelInfo looks[];
   private static int contador=0;
   private item i;
   private int tipo;
     
   public static JTextArea output,statusoutput;
   public static Vector cons,prods;
   public static JLabel statuslabel,status; 

    //variaveis de ajuste de loops vazio 
   //simula processamento no produto e consumidor 
   public static final int tempo = 5;
   //simula processamento no item ou regi�o critica 
   public static final int tempo2 = 3;   
   
   public deposito () {    
      super("Produtores e Consumidores Usando Sincroniza��o");  
      //grupos de threads
      cons = new Vector();
      prods = new Vector();
      
      //objeto monitor para gerenciar a regi�o critica
      String buffer =JOptionPane.showInputDialog(this,"Entre com Tamanho do Buffer  ESC para buffer = 20");
      if (buffer==null)
       i = new item(20);
      else  
       i = new item(Integer.parseInt(buffer));
      
      
      //janelas de saida
      output = new JTextArea(5,40); 
      statusoutput =new JTextArea(15,20);
      status = new JLabel("0");
      
      //paineis
      imput_panel = new JPanel();
      status_panel 	= new JPanel();
      area_panel =new JPanel();
      imput_panel.setLayout(new GridLayout(3,4));
      status_panel.setLayout(new GridLayout(1,2));   
	  area_panel.setLayout(new GridLayout(1,2));  
	  //container do frame principal
      c = getContentPane();
      c.setLayout(new BorderLayout() );
      
      //iterface grafica
      statuslabel = new JLabel("Valor Do Buffer Atual     :");     
      l1= new JLabel("Prudutor ID:");
      l2= new JLabel("Prudutor Prioridade:");	  
      l3= new JLabel("Consumidor ID:");
      l4= new JLabel("Consumidor Prioridade:");	  
      pid= new JTextField(); 
      pprio= new JTextField();
      cid= new JTextField();
      cprio= new JTextField();
      Criap = new JButton("Cria Produtor"); 
      Criap.addActionListener( new ActionListener()
      { public void actionPerformed( ActionEvent e)
        { // referecia para o produtor  
          produtor p = new produtor(pid.getText(),pprio.getText(),i);
	      // ativo
	      p.morto=false;
	      //adicionando o produtor na lista de produtores	      
	      p.stado="Produtor :"+ p.getName()+"["+p.getPriority()+"]"+" Pronto\n";
	      prods.add(p);
	      //iniciando o produtor
	       p.start();
	    }  
      }); 	
      Criac = new JButton("Cria Consumidor"); 
      Criac.addActionListener( new ActionListener()
      { public void actionPerformed( ActionEvent e)
        { 
          consumidor c = new consumidor(cid.getText(),cprio.getText(),i); 
          c.morto=false;
          c.stado="Consumidor :"+c.getName()+"["+c.getPriority()+"]"+" Pronto\n";
          
          cons.add(c);
          c.start();      
             
        }  
       }); 	
       
      Matac = new JButton("Mata Consumidor"); 
      Matac.addActionListener( new ActionListener()
      { public void actionPerformed( ActionEvent e)
        { //loop no vetor de consumidores procurando o consumidor para matar
          consumidor ref ;
          for (int cont=0;cont<cons.size();cont++)
          { ref = (consumidor)cons.get(cont) ;
            if (ref.getName().equals(cid.getText())) 
              { //setando thread como morto 
                ref.morto=true;  
                //removendo da lista
                cons.remove(cont);
                //chama o coletor de lixo do java
                System.gc();
              }  
          } 	
         }
       });
        	
      Matap = new JButton("Mata Produtor"); 
      Matap.addActionListener( new ActionListener()
      { public void actionPerformed( ActionEvent e)
        { produtor ref ;
          for (int cont=0;cont<prods.size();cont++)
          { ref = (produtor)prods.get(cont) ;
            
          if (ref.getName().equals(pid.getText())) 
             {
              ref.morto=true;       
              prods.remove(cont);
              System.gc();
              }
        
          }
           
         }
       }); 	
      // detalhes da interface grafica
      imput_panel.add(l1);imput_panel.add(pid);imput_panel.add(l3);imput_panel.add(cid);
      imput_panel.add(l2);imput_panel.add(pprio);imput_panel.add(l4);imput_panel.add(cprio);
      imput_panel.add(Criap);imput_panel.add(Matap);imput_panel.add(Criac);imput_panel.add(Matac);
      
      status_panel.add(statuslabel);
      status_panel.add(status);
      
      JScrollPane jp = new JScrollPane(output);
      jp.setHorizontalScrollBarPolicy(jp.HORIZONTAL_SCROLLBAR_NEVER);
    
      area_panel.add(jp);
      area_panel.add(statusoutput);
    
      c.add(area_panel,BorderLayout.CENTER); 
      c.add(imput_panel,BorderLayout.NORTH);
      c.add(status_panel,BorderLayout.SOUTH);
      
     
      //interface grafica
      looks = UIManager.getInstalledLookAndFeels();
      try 
      {
         int value = (int) ( Math.random() * 2 );
         UIManager.setLookAndFeel(looks[0].getClassName() );
         SwingUtilities.updateComponentTreeUI( this );
      }
      catch ( Exception e ) {
         e.printStackTrace();
      }
      setSize(600,300); 
      show();
           
  }      
  //function para atualizar a textarea, realizando loops nos produtores e consumidores, 
  //fazendo a leitura dos seus estados   
   public static void  stado()
  {  
    String str_stado="";
    
     for (int cont=0;cont<deposito.prods.size();cont++)
      { 
      produtor ref1 = (produtor)deposito.prods.get(cont) ;
      str_stado+=ref1.stado; 
      }
     for (int cont=0;cont<deposito.cons.size();cont++)
      {
       consumidor ref2 = (consumidor)deposito.cons.get(cont) ;
       str_stado+=ref2.stado;  
       }
    statusoutput.setText(str_stado);
  }
  
  public static void main( String args[] )
   {
    deposito app = new deposito();
    app.addWindowListener( new WindowAdapter()
    {public void windowClosing(WindowEvent e)
	  { System.exit(0); }
    });
   }
}
