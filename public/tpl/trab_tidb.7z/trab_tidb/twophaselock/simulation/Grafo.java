package twophaselock.simulation;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Vector;


public class Grafo implements Serializable
{
   public Vector nos;   //Vector de n�s
   public Set nosEmCiclo;
//**********************************************************   
//Insere um n�(OBS: o n� ainda n�o existe)
//**********************************************************
   public Grafo()
   {
      nos =new Vector();
   }
//**********************************************************   
//Insere um n�(OBS: o n� ainda n�o existe)
//**********************************************************
   public void insereNo(int id)
   {
      No noAux = new No(id);
      if (nos.indexOf(noAux) == -1) 
      {
         nos.addElement(noAux);
      }
   }
//**********************************************************   
//Remove um n�(o n� ainda n�o existe)
//**********************************************************
   public void excluirNo(int id)
   {
      No noAux=new No(id);
      int indAux = nos.indexOf(noAux);
      if (nos.indexOf(noAux) != -1) 
      {
         for(int i=0;i < nos.size();i++)
         {
            noAux = (No)nos.elementAt(i);
            noAux.excluiAresta(id);
         }
         Object objAux = nos.elementAt(indAux);
         nos.removeElement(objAux);
      }
   }
//**********************************************************   
//Insere Aresta (Se os v�rtices existirem)
//**********************************************************
   public void insereAresta(int id1, int id2)
   {
      No noAux1=new No(id1);
      No noAux2=new No(id2);      
      if ( (nos.indexOf(noAux1) != -1) && (nos.indexOf(noAux2) != -1) && (id1 != id2))
      {
         noAux1 = (No)nos.elementAt( nos.indexOf(noAux1) );   
         noAux2 = (No)nos.elementAt( nos.indexOf(noAux2) );   
         noAux1.insereAresta(noAux2);
      }
   }
//**********************************************************   
//Insere Aresta (Se os v�rtices existirem)
//**********************************************************
   public void excluiAresta(int id1, int id2)
   {
      No noAux1 = new No(id1);
      No noAux2 = new No(id2);      
      if ( (nos.indexOf(noAux1) != -1) && (nos.indexOf(noAux2) != -1) )
      {
         noAux1 = (No)nos.elementAt( nos.indexOf(noAux1) );            
         noAux1.excluiAresta(id2);
      }
   }
//**********************************************************   
//verifica a exist�ncia de ciclo no grafo
//**********************************************************
   public boolean existeCiclo()
   {
      No noAux;
      Bool encontrouCiclo = new Bool(false);
      nosEmCiclo = new HashSet();
      for(int i=0; i<nos.size(); i++)
      {
         noAux = (No)nos.elementAt(i);
         noAux.marcado = false;
         noAux.conect = false;
      }
      for (int i=0; i<nos.size(); i++) {
         noAux = (No)nos.elementAt(i);
         if( (!noAux.conect)&&(!encontrouCiclo.value) ) {
            CicloAux(noAux, encontrouCiclo);
         }
      }
      return encontrouCiclo.value;
   }
//**********************************************************
   private void CicloAux(No noIni,Bool encontrouCiclo)
   {
      No noAux;
      if (noIni.marcado)
      {
         encontrouCiclo.value = true;
      }
      else
      {
         noIni.marcado = true;
         noIni.conect = true;
         for(int j=0; j<noIni.nArestas(); j++)
         {
            noAux = (No)noIni.arestaElementAt(j);
            nosEmCiclo.add(noAux);
            CicloAux(noAux, encontrouCiclo);
            if (!encontrouCiclo.value)
            	nosEmCiclo.remove(noAux);
         }
         noIni.marcado = false;
      }
   }
   
   
}