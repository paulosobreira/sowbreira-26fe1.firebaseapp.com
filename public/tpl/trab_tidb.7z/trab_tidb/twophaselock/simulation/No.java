package twophaselock.simulation;

import java.awt.Point;
import java.io.Serializable;
import java.util.Vector;


public class No implements Serializable
{
   private int idNo;        //identifica��o do n�
   private Vector aresta;   //vetor de n�s referenciados
   public boolean marcado;  //usado na busca de um ciclo
   public boolean conect;
   public boolean desenhado;
   public Point location; 
//**********************************************************   
//Contrutor
//**********************************************************
   public No(int id)
   {  
      idNo= id;
      aresta = new Vector(0);
      marcado = false;
      conect = false;
   }
//**********************************************************   
//retorna o id do n�
//**********************************************************
   public int getIdNo()
   {
      return idNo;
   }
//**********************************************************   
//redefini��o para ser usado em "aresta.indexOf(novaAresta)"
//**********************************************************
   public boolean equals(Object noComparado)
   {  
      No noAux = (No)noComparado;
      if ( noAux.getIdNo()==idNo )
         return true;
      else
         return false;
   }
//**********************************************************   
//Insere Aresta
//**********************************************************
   public void insereAresta(No novaAresta)
   {
      if (aresta.indexOf(novaAresta) == -1) 
      {
         aresta.addElement(novaAresta);
      }

   }
//**********************************************************   
//Exclui Aresta usando o id da aresta
//**********************************************************
   public void excluiAresta(int IdArestaExcluida)
   {
      No noAux = new No(IdArestaExcluida);
      int indAux = aresta.indexOf(noAux);
      if ( indAux != -1 )
      { 
        Object objAux;     
        objAux = aresta.elementAt(indAux);
        aresta.removeElement(objAux);
      }
   }
//**********************************************************   
//restorna o Objeto n� por um �ndice em "aresta"
//**********************************************************
   public No arestaElementAt(int indice)
   {
      return (No)aresta.elementAt(indice);
   }
//**********************************************************   
//retorna o n�mero de arestas
//**********************************************************
   public int nArestas()
   {
      return aresta.size();
   }
	/**
	 * @return Returns the location.
	 */
	public final Point getLocation() {
		return location;
	}
	/**
	 * @param location The location to set.
	 */
	public final void setLocation(Point location) {
		this.location = location;
	}
	/**
	 * @return Returns the aresta.
	 */
	public final Vector getAresta() {
		return aresta;
	}
	/**
	 * @param aresta The aresta to set.
	 */
	public final void setAresta(Vector aresta) {
		this.aresta = aresta;
	}
/**
 * @return Returns the desenhado.
 */
public final boolean isDesenhado() {
	return desenhado;
}
/**
 * @param desenhado The desenhado to set.
 */
public final void setDesenhado(boolean desenhado) {
	this.desenhado = desenhado;
}
}