package twophaselock.simulation;

import java.io.Serializable;

public class Bool implements Serializable
{
   public boolean value;
   public Bool(boolean b)
   {
      value = b;
   }
}