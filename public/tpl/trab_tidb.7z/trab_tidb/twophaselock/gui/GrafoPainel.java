/*
 * Created on 25/05/2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package twophaselock.gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.util.HashSet;
import java.util.Set;

import javax.swing.JPanel;

import twophaselock.simulation.Grafo;
import twophaselock.simulation.No;

/**
 * @author sobreira
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class GrafoPainel extends JPanel{
	
	private Grafo grafo;
	public static int CIMA=50;
	public static int BAIXO=150;
	public static int DES_LATERAL=50;
	
	public void paintComponent(Graphics g ){
      super.paintComponent( g );
      setPreferredSize(new Dimension(500,500));
      Graphics2D g2 = (Graphics2D)g;
      g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
      			RenderingHints.VALUE_ANTIALIAS_ON);
      g2.setRenderingHint(RenderingHints.KEY_RENDERING,
      			RenderingHints.VALUE_RENDER_QUALITY);
      g2.setRenderingHint(RenderingHints.KEY_DITHERING,
      			RenderingHints.VALUE_DITHER_ENABLE);
      g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION ,
      			RenderingHints.VALUE_INTERPOLATION_BILINEAR);
      if (grafo!=null){
	      //desenha nos
	      for (int i = 0; i < grafo.nos.size(); i++) {
	      		No no = (No) grafo.nos.get(i);
      			int lateral = DES_LATERAL*(i+1);
	      		if ((i+1)%2==0){
	      			g.setColor(Color.BLACK);
	      			g.drawString("T"+no.getIdNo(),lateral-10,CIMA);
	      			g.setColor(Color.RED);
	      			g.drawOval(lateral,CIMA,40,40);
	      			no.setLocation(new Point(lateral+20,CIMA+20));
	      		}
	      		else{
	      			g.setColor(Color.BLACK);
	      			g.drawString("T"+no.getIdNo(),lateral-10,BAIXO);
	      			g.setColor(Color.RED);
	      			g.drawOval(lateral,BAIXO,40,40);
	      			no.setLocation(new Point(lateral+20,BAIXO+20));
	      		}
	      }
	      //desenha arrestas
	      Set set = new HashSet();
	      for (int i = 0; i < grafo.nos.size(); i++) {
	      		No no = (No) grafo.nos.get(i);
	      		for (int j = 0; j < no.getAresta().size(); j++) {
					No nextNo= (No) no.getAresta().get(j);
					g.setColor(Color.BLUE);
					if (!set.contains(nextNo)){
						g.setColor(Color.BLUE);
						drawArrow(g,no.getLocation().x,no.getLocation().y,
							nextNo.getLocation().x,nextNo.getLocation().y,
						7.0,8.0);
						g.setColor(Color.DARK_GRAY);
						g.fillOval(no.getLocation().x,no.getLocation().y,5,5);
					}
					else{
						g.setColor(Color.BLUE);
						drawArrow(g,no.getLocation().x+10,no.getLocation().y+5,
							nextNo.getLocation().x+10,nextNo.getLocation().y+5,
						7.0,8.0);
						g.setColor(Color.DARK_GRAY);
						g.fillOval(no.getLocation().x+10,no.getLocation().y+5,
								5,5);
					}
					
	      		}
	      		set.add(no);
	      }
      	}
     }
	/**
	 * Title:        drawArrow
	 * Description:  Draws an arrow
	 * Company:      Transparent Tools (http://transparenttools.com)
	 * @author       Jan Koeman (algorithm designer)
	 */

	// xy1 arrow base
	// xy2 arrow point
	// K   blade height
	// N   blade length (hypotenuse)
	// L   blade width (distance from arrow line)
	void drawArrow(java.awt.Graphics g, int x1, int y1, int x2, int y2, double K, double N){

		if( K >= N ) return; // draw nothing if height is greater than length
		double L = Math.sqrt(N * N - K * K);
		int x = x2 - x1;
		int y = y2 - y1;
		double A = Math.sqrt(x * x + y * y);

		int x3 = (int)(( (A - K) / A) * x - (L / A) * y);
		int y3 = (int)(( (A - K) / A) * y + (L / A) * x);
		int x5 = (int)(( (A - K) / A) * x + (L / A) * y);
		int y5 = (int)(( (A - K) / A) * y - (L / A) * x);

		int x4 = x1 + x3;
		int y4 = y1 + y3;
		int x6 = x1 + x5;
		int y6 = y1 + y5;

		g.drawLine(x1,y1,x2,y2); // line
		g.drawLine(x2,y2,x4,y4); // blade left
		g.drawLine(x2,y2,x6,y6); // blade right

	}	
	/**
	 * @return Returns the grafo.
	 */
	public final Grafo getGrafo() {
		return grafo;
	}
	/**
	 * @param grafo The grafo to set.
	 */
	public final void setGrafo(Grafo grafo) {
		this.grafo = grafo;
	}
}
