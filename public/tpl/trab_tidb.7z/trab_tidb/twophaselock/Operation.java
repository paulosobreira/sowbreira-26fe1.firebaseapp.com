/*
 * Created on 19/05/2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package twophaselock;

/**
 * @author sobreira
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class Operation {
	public final static char READ='r';
	public final static char WRITE='w';
	public final static char COMMIT='c';
	//matriz a titulo de ilustra��o
	public final static boolean[][] MATRIX={{true,false},
											{false,false}};
	
	private char type;
	private boolean grantAccess;
	private boolean commitOp;
	private boolean comited;
	private boolean aborted;
	private Transaction transaction;
	private String itemDb;
	
	public Operation(){
	}
	
	public Operation(char type,Transaction transaction){
		this.type = type;
		this.transaction = transaction;
		this.commitOp = (type!=COMMIT?false:true);
	}
	
	/**
	 * verifica a compatibilidade pelo tipo ou se � mesma transa��o
	 * @param op
	 * @return
	 */
	public boolean isCompatible(Operation op){
		if (this.type==READ && op.getType()==READ ||
			op.getTransaction().equals(getTransaction()))
			return true;
		return false;
	}
	/**
	 * @deprecated
	 *
	 */
	public void processOperation(){
		transaction.processOperation(this);
	}		
	/**
	 * @return Returns the grantAccess.
	 */
	public final boolean isGrantAccess() {
		return grantAccess;
	}
	/**
	 * @param grantAccess The grantAccess to set.
	 */
	public final void setGrantAccess(boolean grantAccess) {
		getTransaction().setDeleyed(!grantAccess);
		this.grantAccess = grantAccess;
	}
	/**
	 * @return Returns the transaction.
	 */
	public final Transaction getTransaction() {
		return transaction;
	}
	/**
	 * @param transaction The transaction to set.
	 */
	public final void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}
	/**
	 * @return Returns the type.
	 */
	public final char getType() {
		return type;
	}
	/**
	 * @param type The type to set.
	 */
	public final void setType(char type) {
		this.type = type;
	}
	/**
	 * @return Returns the itemDb.
	 */
	public final String getItemDb() {
		return itemDb;
	}
	/**
	 * @param itemDb The itemDb to set.
	 */
	public final void setItemDb(String itemDb) {
		this.itemDb = itemDb;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ""+type+transaction.getId()+
			(commitOp?"":"("+itemDb+")")+(grantAccess?"AG":"")   ; 
	}
	/**
	 * @return Returns the commitOp.
	 */
	public final boolean isCommitOp() {
		return commitOp;
	}
	/**
	 * @param commitOp The commitOp to set.
	 */
	public final void setCommitOp(boolean commitOp) {
		this.commitOp = commitOp;
	}
	/**
	 * @return Returns the comited.
	 */
	public final boolean isComited() {
		return comited;
	}
	/**
	 * @param comited The comited to set.
	 */
	public final void setComited(boolean comited) {
		this.comited = comited;
	}
	/**
	 * @return Returns the aborted.
	 */
	public final boolean isAborted() {
		return aborted;
	}
	/**
	 * @param aborted The aborted to set.
	 */
	public final void setAborted(boolean aborted) {
		this.aborted = aborted;
	}
}
