/*
 * Created on 19/05/2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package twophaselock;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * @author sobreira
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class Transaction {
	private int id;
	private int timeStamp;
	private List Operations = new ArrayList();
	private int numOp;
	private boolean deleyed;
	
	public Transaction(){
	}
	
	public Transaction(char id,int timeStamp){
		this.id = Integer.parseInt(new String(new char[]{id}));
		this.timeStamp = timeStamp;
	}

	public void commit() {
		for (Iterator iterator = getOperations().iterator();
		iterator.hasNext();) {
			Operation transOp = (Operation) iterator.next();
			transOp.setComited(true);				
		}
		Scheduler.print("Transa��o "+getId()+" Comitou");
	}
	
	public void processOperation(Operation op){
		//System.out.println("Transa��o "+id+" Processou op "+op);
		numOp++;
	}
	
	public static void main(String[] args) {
	}
	/**
	 * @return Returns the id.
	 */
	public final int getId() {
		return id;
	}
	/**
	 * @param id The id to set.
	 */
	public final void setId(int id) {
		this.id = id;
	}
	/**
	 * @return Returns the operations.
	 */
	public final List getOperations() {
		return Operations;
	}
	/**
	 * @return Returns the timeStamp.
	 */
	public final int getTimeStamp() {
		return timeStamp;
	}
	/**
	 * @param timeStamp The timeStamp to set.
	 */
	public final void setTimeStamp(int timeStamp) {
		this.timeStamp = timeStamp;
	}
	/**
	 * @return Returns the deleyed.
	 */
	public final boolean isDeleyed() {
		return deleyed;
	}
	/**
	 * @param deleyed The deleyed to set.
	 */
	public final void setDeleyed(boolean deleyed) {
		this.deleyed = deleyed;
	}
}
