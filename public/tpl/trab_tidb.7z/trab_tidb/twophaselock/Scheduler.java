/*
 * Created on 19/05/2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package twophaselock;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import twophaselock.simulation.Grafo;
import twophaselock.simulation.No;

/**
 * @author sobreira
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class Scheduler {

	/**
	 * Mapa com todos intes de banco
	 */
	private Map db = new HashMap();
	/**
	 * Mapa com todas as transa��es
	 */
	private Map transactions = new HashMap();
	private static int  timeStamp;
	/**
	 * Scheduller inicial
	 */
	private List inScheduler=  new LinkedList();
	/**
	 * Schedulr Final
	 */
	private List finScheduler=  new ArrayList(); 
	/**
	 * Grafo de espera
	 */
	private Grafo grafo = new Grafo();
	/**
	 * Variavel global para interromper um agendamento q causarar deadlock
	 */
	private boolean cilcoDeadlock;
	/**
	 * Listas de clones de grafos de deadlock
	 */
	private List listDeGrafos;
	/**
	 * buffer para impress�o em GUI
	 */
	public static StringBuffer buffer;
	
	public Scheduler(){
		buffer = new StringBuffer();
		listDeGrafos = new ArrayList();
		timeStamp=0;
	}
	/**
	 * Imprime no console e guada no buffer de testo
	 * @param s
	 */
	public static void print(String s){
		System.out.println(s);
		buffer.append(s+"\n");
	}
	
	/**
	 * Obtem ou gera uma transa��a se a mesa n�o existir
	 * @param Id
	 * @return
	 */	
	public Transaction getTransaction(char Id){
		String transId = new String(new char[]{Id});
		Transaction transaction =
			(Transaction) transactions.get(transId);
		if (transaction==null){
			transaction = new Transaction(Id,timeStamp);
			transactions.put(transId,transaction);
		}
		return transaction;
	}
	/**
	 * transforma a string de entrada em estrutura de dados
	 * @param s
	 */
	public void parseScheduler(String s){
		//come�a do terceiro item ingnorando "s="
		for (int i = 2; i < s.length(); i++) {
			if (s.charAt(i)==Operation.READ){
				Transaction transaction = getTransaction(s.charAt(++i));
				Operation operation = new Operation(Operation.READ,transaction);
				transaction.getOperations().add(operation);
				//pulando (
				i++;
				operation.setItemDb(new String(new char[]{s.charAt(++i)}));
				//pulando )
				i++;
				inScheduler.add(operation);
				timeStamp++;
			}
			if (s.charAt(i)==Operation.WRITE){
				Transaction transaction = getTransaction(s.charAt(++i));
				Operation operation = new Operation(
												Operation.WRITE,transaction);
				transaction.getOperations().add(operation);
				//pulando (
				i++;
				operation.setItemDb(new String(new char[]{s.charAt(++i)}));
				//pulando )
				i++;
				inScheduler.add(operation);
				timeStamp++;
			}
			if (s.charAt(i)==Operation.COMMIT){
				Transaction transaction = getTransaction(s.charAt(++i));
				Operation operation = new Operation(
												Operation.COMMIT,transaction);
				transaction.getOperations().add(operation);
				inScheduler.add(operation);
				timeStamp++;
			}
		}
		//gerando a database
		print("Scheduler entrada :");
		StringBuffer inBuffer = new StringBuffer();
		for (Iterator iter = inScheduler.iterator(); iter.hasNext();) {
			Operation element = (Operation) iter.next();
			inBuffer.append(element);
			if (!element.isCommitOp())
				db.put(element.getItemDb(),new ArrayList());
		}
		print(inBuffer.toString());
		print("Database :");
		print(db.toString());
		for (Iterator iter = transactions.keySet().iterator(); iter.hasNext();) {
			Transaction transaction =
				(Transaction) transactions.get(iter.next());
			grafo.insereNo(transaction.getId());
			print("Transa��o : "+transaction.getId());
			print("  TimeStamp : "+transaction.getTimeStamp());
			print("  Opera��es : "+transaction.getOperations());
		}
	}
	/**
	 * Efetua o agendameto de opera��o equanto existirem opera��es no inScheduler
	 *
	 */
	public void scheduleOperations(){
		while (inScheduler.size()>0){
			for (int i = 0; i < inScheduler.size(); i++) {
				Operation op = (Operation) inScheduler.get(i);
				refreshLocks();
				if (op.isComited() || op.isAborted()){
					inScheduler.remove(op);
					op.setGrantAccess(false);
					break;
				}
				if (op.getType()==Operation.COMMIT && 
						finSchedulerToComit(op)){
					freeAllLocks(op);
					finScheduler.add(op);
					op.getTransaction().commit();
					refreshLocks();
				}
				else if (!op.isCommitOp() && !alreadyLocked(op) && 
							!op.getTransaction().isDeleyed())
					lock(op);
			}
		}
		print("Scheduler Final "+finScheduler.toString());
	}
	/**
	 * verifica se uma transa��o a ser comitada tem toas as suas opera��es 
	 * No scheduler final
	 * @param op
	 * @return
	 */
	private boolean finSchedulerToComit(Operation op){
		boolean ok=true;
		for (Iterator iter = op.getTransaction().getOperations().iterator(); 
		iter.hasNext();) {
			Operation transOp = (Operation) iter.next();
			if (!transOp.isCommitOp() && !finScheduler.contains(transOp))
				ok=false;
		}
		return ok;
	}
	
	/**
	 * Verifica se uma opera��o ja tem blockeio ou esta na fila
	 * @param op
	 * @return
	 */
	
	private boolean alreadyLocked(Operation op){
		boolean ok=false;
		for (Iterator iter = db.keySet().iterator(); iter.hasNext();) {
			String key = (String) iter.next();
			List dbList = (List) db.get(key);
			for (Iterator iterator = dbList.iterator(); iterator.hasNext();) {
				Operation dbOp = (Operation) iterator.next();
				if (dbOp.equals(op))
					ok=true;				
			}
		}
		return ok;
	}
	
	/**
	 * Libera todos os locks
	 * @param op
	 */
	private void freeAllLocks(Operation op) {
		for (Iterator iter = db.keySet().iterator(); iter.hasNext();) {
			String key = (String) iter.next();
			List dbList = (List) db.get(key);
			List transOps = op.getTransaction().getOperations();
			for (Iterator iterator = transOps.iterator(); iterator.hasNext();) {
				Operation transOp = (Operation) iterator.next();
				if (dbList.contains(transOp))
					dbList.remove(transOp);				
			}
		}
		grafo.excluirNo(op.getTransaction().getId());
	}
	/**
	 * Atualiza o estado de todos dos lock nas listas dos itens de db
	 * 
	 */
	private void refreshLocks(){
		for (Iterator iter = db.keySet().iterator(); iter.hasNext();) {
			String key = (String) iter.next();
			List dbList = (List) db.get(key);
			if (!dbList.isEmpty()){
				Operation op = (Operation) dbList.get(0);
				op.setGrantAccess(true);
				if (!finScheduler.contains(op)) 
					finScheduler.add(op);
			}
			List acessList = new ArrayList();
			for (int i = 0; i < dbList.size(); i++) {
				Operation op = (Operation) dbList.get(i);
				if (op.isGrantAccess())
					acessList.add(op);
			}
			for (int i = 0; i < dbList.size(); i++) {
				Operation op = (Operation) dbList.get(i);
				if (op.isGrantAccess())
					continue;
				boolean grantAccess=true;
				for (int j = 0; j < acessList.size(); j++) {
					Operation opAcess = (Operation) acessList.get(j);
					if (!op.isCompatible(opAcess)){
						grantAccess=false;
						conflitTransactions(opAcess,op);
						if (cilcoDeadlock)
							cilcoDeadlock = false;
					}
				}
				op.setGrantAccess(grantAccess);
				if (grantAccess)
					finScheduler.add(op);
			}
		}
	}
	/**
	 * Tenta obter um lock em um objeto nas listas de db
	 * @param op
	 */
	public void lock(Operation op){
		List dbList = (List) db.get(op.getItemDb());
	   if (dbList.isEmpty() && !op.getTransaction().isDeleyed()){
			op.setGrantAccess(true);
			finScheduler.add(op);
			dbList.add(op);
			return;
		}
		boolean grantAccess = true;
		if (!dbList.isEmpty()){
			List acessList = new ArrayList();
			for (int i = 0; i < dbList.size(); i++) {
				Operation opAux = (Operation) dbList.get(i);
				if (opAux.isGrantAccess())
					acessList.add(opAux);
			}
			for (int j = 0; j < acessList.size(); j++) {
				Operation opAcess = (Operation) acessList.get(j);
				if (!opAcess.isCompatible(op)){
					grantAccess = false;
					conflitTransactions(opAcess,op);
					if (cilcoDeadlock){
						cilcoDeadlock = false;
						return;
					}
				}
			}
		}
		op.setGrantAccess(grantAccess);
		dbList.add(op);
		if (grantAccess)
			finScheduler.add(op);
	}

	/**
	 * Atualiza o grafo de espera e vefica a existencia de deadlock
	 * @param dbOp opra��o com bloqueio
	 * @param op opera��o querendo bloqueio
	 */
	private void conflitTransactions(Operation dbOp, Operation op) {
		grafo.insereAresta(dbOp.getTransaction().getId(),
							op.getTransaction().getId());
		if (grafo.existeCiclo()){
			cilcoDeadlock = true;
			print("Deadlock Detectado");
			print("Estado db :"+db.toString());
			try {
				listDeGrafos.add(ObjectCloner.deepCopy(grafo));
			} catch (Exception e) {
				e.printStackTrace();
			}
			int maisNova=0;
			int idMaisNova=9999999;
			for (Iterator iter = grafo.nosEmCiclo.iterator(); iter.hasNext();)
			{
				No no = (No) iter.next();
				Transaction transaction = (Transaction) 
							transactions.get(String.valueOf(no.getIdNo()));
				if (maisNova <= transaction.getTimeStamp()){
					maisNova = transaction.getTimeStamp();
					idMaisNova = transaction.getId(); 
				}
			}
			abortTransaction((Transaction)
						transactions.get(String.valueOf(idMaisNova)));
		}
	}

	/**
	 * Aborta uma transa��o liberando todos os sues locks
	 * @param transaction
	 */
	private void abortTransaction(Transaction transaction) {
		print("Abortando Transa��o "+transaction.getId());
		for (Iterator iter = transaction.getOperations().iterator();
		iter.hasNext();) {
			Operation op = (Operation) iter.next();
			freeAllLocks(op);
			op.setAborted(true);
			if (finScheduler.contains(op))
				finScheduler.remove(op);
		}
	}

	public static void main(String[] args) throws Exception {
		if (args.length<0)
			return;
		BufferedReader in=new BufferedReader(new FileReader(args[0]));
		String line=in.readLine();
		Scheduler scheduler = new Scheduler();
		scheduler.parseScheduler(line);
		scheduler.scheduleOperations();
/*		print("Enter para fechar");
		in=new BufferedReader(new InputStreamReader(System.in));
		in.read();*/
	}
	/**
	 * @return Returns the grafo.
	 */
	public final Grafo getGrafo() {
		return grafo;
	}
	/**
	 * @param grafo The grafo to set.
	 */
	public final void setGrafo(Grafo grafo) {
		this.grafo = grafo;
	}
	/**
	 * @return Returns the listDeGrafos.
	 */
	public final List getListDeGrafos() {
		return listDeGrafos;
	}
	/**
	 * @param listDeGrafos The listDeGrafos to set.
	 */
	public final void setListDeGrafos(List listDeGrafos) {
		this.listDeGrafos = listDeGrafos;
	}
}
