/*
 * TinyBasicToken.java
 *
 * Created on 4 de Setembro de 2003, 19:40
 */

/**
 *
 * @author  Paulo Sobreira
 */
public class TinyBasicToken {
    
    public static final String IDENTIFICADOR="IDENTIFICADOR";
    public static final String PALAVRA_RESERVADA="PALAVRA_RESERVADA";
    public static final String NUMERO_INTEIRO="NUMERO_INTEIRO";
    public static final String SIMBOLO_SIMPLES="SIMBOLO_SIMPLES";
    public static final String SIMBOLO_COMPOSTO="SIMBOLO_COMPOSTO";
    public static final String SIMBOLO_ESTRANHO="SIMBOLO_ESTRANHO";
    public static final String ARRAY_PALAVRAS_RESERVADAS[]={"END","LET","GOTO","OF","READ","PRINT","IF","THEN","ELSE"}; 
    private String estado;
    private String conteudo;
    private int linha;
    /** Creates a new instance of token */
    public TinyBasicToken(String in) {
        conteudo=in;
    }
    
    public void setLinha(int i){
    	linha=i;
    }
    public int getLinha(){
    	return linha;
    }
       
    public String toString(){
        return conteudo+" tipo "+getEstado()+" linha "+linha;
    }
  
    /** Getter for property estado.
     * @return Value of property estado.
     *
     */
    public String getEstado() {
        return estado;
    }
    
    /** Setter for property estado.
     * @param estado New value of property estado.
     *
     */
    public void setEstado(String estado) {
      if (estado.equals(IDENTIFICADOR)) 
       for(int i=0;i<ARRAY_PALAVRAS_RESERVADAS.length;i++)
            if (ARRAY_PALAVRAS_RESERVADAS[i].equals(conteudo)){
                this.estado=PALAVRA_RESERVADA;
                return;
            }          
       this.estado = estado;
    }
    
    /** Getter for property conteudo.
     * @return Value of property conteudo.
     *
     */
    public java.lang.String getConteudo() {
        return conteudo;
    }
    
}

