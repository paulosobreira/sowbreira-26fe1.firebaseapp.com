
/*
 * Identificador.java
 *
 * Created on 28 de Agosto de 2003, 19:41
 */

/**
 *
 * @author  Paulo Sobreira
 */
public class AnalisadorLexico {
    
    /** Creates a new instance of natural */
    public AnalisadorLexico() {
    }
    public String removeDaString(String in,String rem){
        java.util.StringTokenizer st= new java.util.StringTokenizer(in,rem);
        String temp=new String();
        while (st.hasMoreTokens())
            temp+=st.nextToken()+" ";
        return temp;
    }        
    
    public String AnalisaTyniBasic(String in){
	tokensList = new java.util.ArrayList();
        in=in.toUpperCase();
        int cont=0;
        int linha=1;
	String numero="";
	String indent="";
	String saida="";
	while (cont<in.length()){
           if (Character.isSpaceChar(in.charAt(cont)) || (in.charAt(cont)=='\t'))
                   cont++;
               //NUMERO_INTEIRO
	       else if (in.charAt(cont)=='\n'){
				   cont++;
				   linha++;       	
	         }
	       else if (Character.isDigit(in.charAt(cont))){
        		while(cont<in.length() && (Character.isDigit(in.charAt(cont))))
                             numero+=in.charAt(cont++);
                TinyBasicToken tk =new TinyBasicToken(numero);
                tk.setEstado(TinyBasicToken.NUMERO_INTEIRO);
                tk.setLinha(linha);
                tokensList.add(tk);
		numero="";
 		}
               //ESTRANHO
               else if ((!Character.isLetter(in.charAt(cont)) && (!Character.isDigit(in.charAt(cont)))) 
               && !(in.charAt(cont)==ESPACO) && !(isSimSimp(String.valueOf(in.charAt(cont)))) ) {
			while(  cont<in.length() && 
                                ((!Character.isLetter(in.charAt(cont)) && (!Character.isDigit(in.charAt(cont))))) 
                                &&!(in.charAt(cont)==ESPACO) && !(isSimSimp(String.valueOf(in.charAt(cont))))) 
                            indent+=in.charAt(cont++);
                TinyBasicToken tk =new TinyBasicToken(indent);
                tk.setEstado(TinyBasicToken.SIMBOLO_ESTRANHO);
                tk.setLinha(linha);                
                tokensList.add(tk);
                indent="";
		}
               //IDENTIFICADOR
                else if (!(Character.isDigit(in.charAt(cont))) &&!(isSimSimp(String.valueOf(in.charAt(cont)))))  {
			while(cont<in.length() && !(in.charAt(cont)==ESPACO) &&
                        (((Character.isLetterOrDigit((in.charAt(cont))) && !(isSimSimp(String.valueOf(in.charAt(cont))))) ))) 
				indent+=in.charAt(cont++);
                TinyBasicToken tk =new TinyBasicToken(indent);
                tk.setEstado(TinyBasicToken.IDENTIFICADOR);
                tk.setLinha(linha);
                tokensList.add(tk);
		indent="";
		}
               //SIMBOLO_COMPOSTO
               else if( (cont<in.length()) && (in.charAt(cont)==DOISPONTOS) &&
                    ((cont+1<in.length()) && (in.charAt(cont+1)==IGUAL))){
                              indent+=in.charAt(cont++);
                              indent+=in.charAt(cont++);
                TinyBasicToken tk =new TinyBasicToken(indent);
                tk.setEstado(TinyBasicToken.SIMBOLO_COMPOSTO);
                tk.setLinha(linha);
                tokensList.add(tk);
                indent="";               
               }
               //SIMBOLO_COMPOSTO =>
               else if( (cont<in.length()) && (in.charAt(cont)==IGUAL) &&
                    ((cont+1<in.length()) && ((in.charAt(cont+1)==MAIORQUE)) )){
                              indent+=in.charAt(cont++);
                              indent+=in.charAt(cont++);
                TinyBasicToken tk =new TinyBasicToken(indent);
                tk.setEstado(TinyBasicToken.SIMBOLO_COMPOSTO);
                tk.setLinha(linha);
                tokensList.add(tk);
                indent="";               
               }
               //SIMBOLO_COMPOSTO <=
               else if( (cont<in.length()) && (in.charAt(cont)==MENORQUE) &&
                    ((cont+1<in.length()) && ((in.charAt(cont+1)==IGUAL) )))  {
                              indent+=in.charAt(cont++);
                              indent+=in.charAt(cont++);
                TinyBasicToken tk =new TinyBasicToken(indent);
                tk.setEstado(TinyBasicToken.SIMBOLO_COMPOSTO);
                tk.setLinha(linha);
                tokensList.add(tk);
                indent="";               
               }
               //SIMBOLO_SIMPLES
               else if(cont<in.length() && (isSimSimp(String.valueOf(in.charAt(cont))))){
                              indent+=in.charAt(cont++);
                TinyBasicToken tk =new TinyBasicToken(indent);
                tk.setEstado(TinyBasicToken.SIMBOLO_SIMPLES);
                tk.setLinha(linha);
                tokensList.add(tk);
                indent="";               
               }
               else
                   cont++;
               
        }
       return saida;	
 }

    public static String Analisa(String in){
	int cont=0;
	String numero="";
	String indent="";
	String saida="";
	boolean pass=true;
	while (cont<in.length()){
	       if (Character.isDigit(in.charAt(cont))){
			int contavirg=0;
			while(cont<in.length() && (Character.isDigit(in.charAt(cont))||
                                                in.charAt(cont)==VIRGULA )){
                                if (in.charAt(cont)==VIRGULA)
					contavirg++;
                                if (contavirg<=1) 
                                    if ((in.charAt(cont)==VIRGULA) && cont+1<in.length() && Character.isDigit(in.charAt(cont+1)))
                                        numero+=in.charAt(cont++);
                                    else if (cont<in.length() && (Character.isDigit(in.charAt(cont))))
                                        numero+=in.charAt(cont++);
                                    else
                                     break;
                                else
                                 break;
                        }
                saida+=numero+" � numero\n";
		numero="";
 		}
               else if ((in.charAt(cont)==SINAL.charAt(0) || 
				  in.charAt(cont)==SINAL.charAt(1))&& 
						Character.isDigit(in.charAt(cont+1))) {
			numero+=in.charAt(cont++);
			int contavirg=0;
			while(cont<in.length() && (Character.isDigit(in.charAt(cont))
								   ||in.charAt(cont)==VIRGULA)){
				if (in.charAt(cont)==VIRGULA) 
					contavirg++;
				if (contavirg<=1)
                                    if ((in.charAt(cont)==VIRGULA) && cont+1<in.length() && Character.isDigit(in.charAt(cont+1)))
                                        numero+=in.charAt(cont++);
                                    else if (cont<in.length() && (Character.isDigit(in.charAt(cont))))
                                        numero+=in.charAt(cont++);
                                    else
                                     break;                                
				else
                                    break;
			}
		saida+=numero+" � numero\n";
		numero="";
		}
               else if (Character.isLetter(in.charAt(cont))){
			while(cont<in.length() && 
                        (Character.isLetter(in.charAt(cont)) || Character.isDigit(in.charAt(cont))) )
				indent+=in.charAt(cont++);
		saida+=indent+" � identificador\n";
		indent="";
		}
               else if (!(Character.isLetter(in.charAt(cont)) || Character.isDigit(in.charAt(cont)))) {
			while(  cont<in.length() && 
                                (!(Character.isLetter(in.charAt(cont)) || Character.isDigit(in.charAt(cont))) ) 
                                &&
                                !((in.charAt(cont)==SINAL.charAt(0) || 
				  in.charAt(cont)==SINAL.charAt(1))&& 
				  cont+1<in.length() &&	Character.isDigit(in.charAt(cont+1)))
                                )
                            indent+=in.charAt(cont++);
		saida+=indent+" � estranho\n";
                indent="";
		} 
        }
       return saida;	
 }
  
     public static boolean isSimSimp(String c) {
        String temp="; : + - * / ( ) , > = <";   
        java.util.StringTokenizer SimSimp= new java.util.StringTokenizer(temp," ");
         while (SimSimp.hasMoreTokens())
            if (c.equals(SimSimp.nextToken()))
              return true;
        return false;
    }  
     public static boolean isSimCom(String c) {
        String temp="> = <";   
        java.util.StringTokenizer SimCom= new java.util.StringTokenizer(temp," ");
         while (SimCom.hasMoreTokens())
            if (c.equals(SimCom.nextToken()))
              return true;
        return false;
    }  
     

    public static void main(String[] args) {
    /*
        while (true){
	     String s =javax.swing.JOptionPane.showInputDialog(null,"Entre com a Cadeia\nEnter para sair");
	     if (s==null ||s.equals("") )
	     	System.exit(0); 
	     String r =Analisa(s);
             javax.swing.JOptionPane.showMessageDialog(null,"String Analisada :"+s+"\n"+ r);
  	 }
    */
        while (true){
	     String s =javax.swing.JOptionPane.showInputDialog(null,"Entre com a Cadeia\nEnter para sair");
	     if (s==null ||s.equals("") )
	     	System.exit(0); 
	     AnalisadorLexico al=new AnalisadorLexico();
             String r =al.AnalisaTyniBasic(s);
             javax.swing.JOptionPane.showMessageDialog(null,"String Analisada "+s+"\n"+"Tokens "+al.tokensList);
  	 }
    }
    
    public java.util.ArrayList tokensList;
    private static String DIGITO="0123456789";
    private static String SINAL="+-";
    private static char VIRGULA=',';
    private static char ESPACO=' ';
    private static char IGUAL='=';
    private static char DOISPONTOS=':';
    private static char MAIORQUE='>';
    private static char MENORQUE='<';
}