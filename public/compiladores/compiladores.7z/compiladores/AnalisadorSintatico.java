/*
 * AnalisadorSintatico.java
 *
 * Created on 18 de Setembro de 2003, 19:48
 */

/**
 *
 * @author  Paulo Sobreira
 */
import javax.swing.tree.*;
import javax.swing.*;
public class AnalisadorSintatico {
    
    /** Creates a new instance of AnalisadorSintatico */
    public AnalisadorSintatico(java.util.ArrayList a) {
        list=a;
      root = new DefaultMutableTreeNode("Programa");
      prog(root);
    }
    public JTree getTree(){
      model = new DefaultTreeModel(root);
      tree = new JTree(model);
      return tree;
    }
        
    public boolean verifica(String s){
        if (index<list.size())
            if (s.equals( ((TinyBasicToken)list.get(index)).getConteudo() ))
                return true;
        return false;
    }
    public boolean verificaTipo(String s){
       if (index<list.size())
            if (s.equals( ((TinyBasicToken)list.get(index)).getEstado() ))
                return true;
        return false;
    }    
    public void erro(String s,DefaultMutableTreeNode node,TinyBasicToken tk){
               if (!error){      
                    javax.swing.JOptionPane.showMessageDialog(null,s+" Esperado na linha"+(tk.getLinha()==1?tk.getLinha():(tk.getLinha()>((list.size()+1)/2)?tk.getLinha()-1:tk.getLinha())),"Erro!",javax.swing.JOptionPane.ERROR_MESSAGE);
                    //javax.swing.tree.TreePath path = new javax.swing.tree.TreePath(model.getPathToRoot(node));
                    //tree.expandPath(path);
                    error=true;
               }
                     return;
    }
    public TinyBasicToken getToken(){
            if (index>=list.size())
                return (TinyBasicToken)list.get(index-1);
            else
                return (TinyBasicToken)list.get(index);
    }
    
    public void prog(DefaultMutableTreeNode node) {
        DefaultMutableTreeNode secom=new DefaultMutableTreeNode("Sequ�ncia de comandos");
        node.add(secom);
        secom(secom);
        if (verifica("END")){
            index++;
            node.add(new DefaultMutableTreeNode("END"));
        }
        else
            erro("End ",node,getToken());
    }
    
    public void secom(DefaultMutableTreeNode node) {
        DefaultMutableTreeNode cmd=new DefaultMutableTreeNode("Comando");
        node.add(cmd);
        cmd(cmd);
        DefaultMutableTreeNode secom2=new DefaultMutableTreeNode("Sequ�ncia de comandos'");
        node.add(secom2);
        secom2(secom2);
    }
    public void secom2(DefaultMutableTreeNode node) {
        if (verifica(";")){
            index++;
            node.add(new DefaultMutableTreeNode(";"));
            DefaultMutableTreeNode cmd=new DefaultMutableTreeNode("Comando");
            node.add(cmd);
            cmd(cmd);
            DefaultMutableTreeNode secom2=new DefaultMutableTreeNode("Sequ�ncia de comandos'");
            node.add(secom2);
            secom2(secom2);            
        }
    }
        
    public void cmd(DefaultMutableTreeNode node) {
        if (verifica("LET")){
            DefaultMutableTreeNode atrib=new DefaultMutableTreeNode("Atribui��o");
            node.add(atrib);
            atrib(atrib);
        }
        else if (verifica("GOTO")){
            DefaultMutableTreeNode desv=new DefaultMutableTreeNode("Desvio");
            node.add(desv);            
            desv(desv);
        }
        else if (verifica("READ")){
            DefaultMutableTreeNode lei=new DefaultMutableTreeNode("Leitura");
            node.add(lei);
            lei(lei);
        }
        else if (verifica("PRINT")){
            DefaultMutableTreeNode imp=new DefaultMutableTreeNode("Impress�o");
            node.add(imp);            
            imp(imp);
        }
        else if (verifica("IF")){
            DefaultMutableTreeNode deci=new DefaultMutableTreeNode("Decis�o");
            node.add(deci);
            deci(deci);
        }
        else if (verificaTipo(TinyBasicToken.IDENTIFICADOR)){
            node.add(new DefaultMutableTreeNode(list.get(index)));  
            index++;
            if (verifica(":")){
                index++;
                node.add(new DefaultMutableTreeNode(":"));
                DefaultMutableTreeNode cmd=new DefaultMutableTreeNode("Comando");
                node.add(cmd);                
                cmd(cmd);
            }
        }
                          
    }
    
    public void atrib(DefaultMutableTreeNode node) {
	   node.add(new DefaultMutableTreeNode("LET"));
	   index++;
       if (verificaTipo(TinyBasicToken.IDENTIFICADOR)){
           node.add(new DefaultMutableTreeNode(list.get(index)));
           index++;
           if (verifica(":=")){
            index++;
            node.add(new DefaultMutableTreeNode(":="));
            DefaultMutableTreeNode exp=new DefaultMutableTreeNode("Express�o");
            node.add(exp);         
            exp(exp);
           }
           else erro(":=",node,getToken());
       }
       else erro(TinyBasicToken.IDENTIFICADOR,node,getToken());
    }
    public void exp(DefaultMutableTreeNode node) {
        DefaultMutableTreeNode ter=new DefaultMutableTreeNode("Termo");
        node.add(ter);        
        ter(ter);
        DefaultMutableTreeNode exp2=new DefaultMutableTreeNode("Express�o'");
        node.add(exp2);         
        exp2(exp2);
    }
    public void exp2(DefaultMutableTreeNode node) {
        if (verifica("+")){
            node.add(new DefaultMutableTreeNode("+"));
            index++;
            DefaultMutableTreeNode ter=new DefaultMutableTreeNode("Termo");
            node.add(ter);        
            ter(ter);
            DefaultMutableTreeNode exp2=new DefaultMutableTreeNode("Express�o'");
            node.add(exp2);         
            exp2(exp2);            
        }
        else if (verifica("-")){
            node.add(new DefaultMutableTreeNode("-"));
            index++;
            DefaultMutableTreeNode ter=new DefaultMutableTreeNode("Termo");
            node.add(ter);        
            ter(ter);
            DefaultMutableTreeNode exp2=new DefaultMutableTreeNode("Express�o'");
            node.add(exp2);         
            exp2(exp2);
        }
           
    }    
    public void ter(DefaultMutableTreeNode node) {
        DefaultMutableTreeNode fat=new DefaultMutableTreeNode("Fator");
        node.add(fat);
        fat(fat);
        DefaultMutableTreeNode ter2=new DefaultMutableTreeNode("Termo'");
        node.add(ter2);
        ter2(ter2);
    }
    public void ter2(DefaultMutableTreeNode node) {
        if (verifica("*")){
            node.add(new DefaultMutableTreeNode("*"));
            index++;
            DefaultMutableTreeNode fat=new DefaultMutableTreeNode("Fator");
            node.add(fat);
            fat(fat);
            DefaultMutableTreeNode ter2=new DefaultMutableTreeNode("Termo'");
            node.add(ter2);
            ter2(ter2);
        }
        else if (verifica("/")){
            node.add(new DefaultMutableTreeNode("/"));
            index++;
            DefaultMutableTreeNode fat=new DefaultMutableTreeNode("Fator");
            node.add(fat);
            fat(fat);
            DefaultMutableTreeNode ter2=new DefaultMutableTreeNode("Termo'");
            node.add(ter2);
            ter2(ter2);
        }
    }    
    public void desv(DefaultMutableTreeNode node) {
    	node.add(new DefaultMutableTreeNode("GOTO"));
    	index++;
    	if (verificaTipo(TinyBasicToken.IDENTIFICADOR)){
    		DefaultMutableTreeNode ident =new DefaultMutableTreeNode(list.get(index));
                node.add(ident);
    		index++;
    		if (verifica("OF")){
    			node.add(new DefaultMutableTreeNode("OF"));
    			index++;
    			DefaultMutableTreeNode lrot=new DefaultMutableTreeNode("Lista de R�tulos");
                	node.add(lrot);
    			lrot(lrot);
    		}
    		else{ 
                    index--;
                    if (verificaTipo(TinyBasicToken.IDENTIFICADOR)){
			DefaultMutableTreeNode rot=new DefaultMutableTreeNode("R�tulo");
		        node.add(rot);
                        node.remove(ident);
        		rot(rot);
			}    		
                    else
                       erro("OF",node,getToken());
                }
        }
        else 
             erro(TinyBasicToken.IDENTIFICADOR,node,getToken());
    }
    
    public void lei(DefaultMutableTreeNode node) {
        if (verifica("READ")){
            node.add(new DefaultMutableTreeNode("READ"));
            index++;
            DefaultMutableTreeNode lide=new DefaultMutableTreeNode("Lista de identificadores");
            node.add(lide);
            lide(lide);
        }
    }
    
    public void imp(DefaultMutableTreeNode node) {
        if (verifica("PRINT"))
            node.add(new DefaultMutableTreeNode("PRINT"));
            index++;
            DefaultMutableTreeNode lexp=new DefaultMutableTreeNode("Lista de Express�es");
            node.add(lexp);
            lexp(lexp);
            if (verifica(",")){
            	node.add(new DefaultMutableTreeNode(list.get(index)));
                index++;
	            DefaultMutableTreeNode lexp2=new DefaultMutableTreeNode("Lista de Express�es");
	            node.add(lexp2);
	            lexp(lexp2);
            }
    }
    
    public void deci(DefaultMutableTreeNode node) {
        if (verifica("IF")){
        	index++;
            node.add(new DefaultMutableTreeNode("IF")); 
            DefaultMutableTreeNode comp=new DefaultMutableTreeNode("Compara��o");
            node.add(comp);
            comp(comp);
            if (verifica("THEN")){
                index++;
                node.add(new DefaultMutableTreeNode("THEN")); 
                DefaultMutableTreeNode cmd=new DefaultMutableTreeNode("Comando");
                node.add(cmd);
                cmd(cmd);
                if (verifica("ELSE")){
                    node.add(new DefaultMutableTreeNode("ELSE"));
                    index++;
                    DefaultMutableTreeNode cmd2=new DefaultMutableTreeNode("Comando");
                    node.add(cmd2);
                    cmd(cmd2);
                }
                else
                  erro("ELSE",node,getToken());
            }
            else
                erro("THEN",node,getToken());
        }
        else
            erro("IF",node,getToken());
            
                
        
    }
    
    public void rot(DefaultMutableTreeNode node) {
    	if (verificaTipo(TinyBasicToken.IDENTIFICADOR)){
    		node.add(new DefaultMutableTreeNode(list.get(index)));
    		index++;
    	}
    	else
    		erro(TinyBasicToken.IDENTIFICADOR,node,getToken());
    }

    public void lrot(DefaultMutableTreeNode node) {
		DefaultMutableTreeNode rot=new DefaultMutableTreeNode("R�tulo");
                node.add(rot);
		rot(rot);
		DefaultMutableTreeNode lrot2=new DefaultMutableTreeNode("Lista de R�tulos'");
        	node.add(lrot2);
		lrot2(lrot2);
    	
    }

    public void lrot2(DefaultMutableTreeNode node) {
        if (verifica(",")){
            node.add(new DefaultMutableTreeNode(","));
            index++;
		DefaultMutableTreeNode rot=new DefaultMutableTreeNode("R�tulo");
	        node.add(rot);
		rot(rot);
		DefaultMutableTreeNode lrot2=new DefaultMutableTreeNode("Lista de R�tulos'");
	    	node.add(lrot2);
		lrot2(lrot2);
        }
    }

    public void fat(DefaultMutableTreeNode node) {
        if (verificaTipo(TinyBasicToken.IDENTIFICADOR)){
            node.add(new DefaultMutableTreeNode(list.get(index)));
            index++;
        }
        else if (verificaTipo(TinyBasicToken.NUMERO_INTEIRO)){
            node.add(new DefaultMutableTreeNode(list.get(index)));
            index++;
        }
        else if (verifica("(")){
            node.add(new DefaultMutableTreeNode("("));
            index++;
            DefaultMutableTreeNode exp=new DefaultMutableTreeNode("Express�o");
            node.add(exp);
            exp(exp);
            if (verifica(")")){
                node.add(new DefaultMutableTreeNode("("));
                index++;
            }
            else
                erro(")",node,getToken());
        }
        else
            erro(TinyBasicToken.IDENTIFICADOR+" ou "+TinyBasicToken.NUMERO_INTEIRO+" ou (",node,getToken());
            
    }
    
    
    public void lide(DefaultMutableTreeNode node) {
        if (verificaTipo(TinyBasicToken.IDENTIFICADOR)){
            node.add(new DefaultMutableTreeNode(list.get(index)));
            index++;
            if (verifica(",")){
                node.add(new DefaultMutableTreeNode(","));
                index++;
                DefaultMutableTreeNode lide=new DefaultMutableTreeNode("Lista de identificadores");
                node.add(lide);
                lide(lide);
            }
            else 
                erro(",",node,getToken());
        }
    }
    
    public void lexp(DefaultMutableTreeNode node) {        
        DefaultMutableTreeNode exp=new DefaultMutableTreeNode("Express�o");
        node.add(exp);
        exp(exp);
        if (verifica(",")){
            index++;
            DefaultMutableTreeNode lexp=new DefaultMutableTreeNode("Lista de Express�es");
            node.add(lexp);
            lexp(lexp);
        }
    }
    
    public void comp(DefaultMutableTreeNode node) {
        DefaultMutableTreeNode exp=new DefaultMutableTreeNode("Express�o");
        node.add(exp);
        exp(exp);
        DefaultMutableTreeNode opcomp=new DefaultMutableTreeNode("Operador de Compara��o");
        node.add(opcomp);
        opcomp(opcomp);
        DefaultMutableTreeNode exp2=new DefaultMutableTreeNode("Express�o");
        node.add(exp2);
        exp(exp2);
    }
    
    public void opcomp(DefaultMutableTreeNode node) {
        if (verifica("=>")){
            node.add(new DefaultMutableTreeNode("=>")); 
            index++;
        }
        else if (verifica("=")){
            node.add(new DefaultMutableTreeNode("=")); 
            index++;
        }
        else if (verifica("<")){
            node.add(new DefaultMutableTreeNode("<")); 
            index++;
        }
        else if (verifica("<=")){
            node.add(new DefaultMutableTreeNode("<=")); 
            index++;
        }
        else if (verifica(">")){
            node.add(new DefaultMutableTreeNode(">")); 
            index++;
        }
        else
            erro("Operadore de Compara��o ",node,getToken());
    }
   private boolean error; 
   private int index;
   private java.util.ArrayList list;
   private JTree tree;
   private DefaultTreeModel model;
   private DefaultMutableTreeNode root;    
}
