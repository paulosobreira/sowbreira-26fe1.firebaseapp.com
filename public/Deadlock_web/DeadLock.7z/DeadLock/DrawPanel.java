package sowbreira.so.deadlock;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.geom.*;



public class DrawPanel extends JPanel {
    private JComboBox rec_combo,proc_combo;
    public int largura=800;

  public DrawPanel( JComboBox proc,JComboBox rec )
   {
      rec_combo=rec;
      proc_combo=proc;     
      setPreferredSize(new Dimension(largura,190));
    //  setSize(1000,400);
   }
   
   
   public void paintComponent( Graphics g )
     {
      super.paintComponent( g );
      setPreferredSize(new Dimension(largura,190));
      
      Graphics2D g2 = (Graphics2D)g;
      g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
      g2.setRenderingHint(RenderingHints.KEY_RENDERING,RenderingHints.VALUE_RENDER_QUALITY);
      g2.setRenderingHint(RenderingHints.KEY_DITHERING,RenderingHints.VALUE_DITHER_ENABLE);
      g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION ,RenderingHints.VALUE_INTERPOLATION_BILINEAR);
 

      
      desenharRecurso( g );       
      desenharProcesso( g );
      //desenharProcessoAA( g2 );
      desenharSetas( g );
      //desenharSetasAA( g2 );
     }
     
     public  void desenharProcesso( Graphics g )
      {
     	 for (int cont=0;cont<proc_combo.getItemCount();cont++)
         {
         processo proc_ref=(processo)proc_combo.getItemAt(cont);
         proc_ref.y=10;
         proc_ref.x=cont*100+10;
        
         g.drawOval(proc_ref.x, proc_ref.y+10,40,40);
         g.drawString(proc_ref.toString(),proc_ref.x,proc_ref.y);
                 
         }
      
       }
     
     public  void desenharProcessoAA( Graphics2D g )
      {
     	 for (int cont=0;cont<proc_combo.getItemCount();cont++)
         {
         processo proc_ref=(processo)proc_combo.getItemAt(cont);
         proc_ref.y=10;
         proc_ref.x=cont*100+10;
   
         
         g.draw(new Ellipse2D.Double(proc_ref.x, proc_ref.y+10,40,40));
         //g.drawString(proc_ref.toString(),proc_ref.x,proc_ref.y);
                 
         }
      
       }
          
     
     
      public  void  desenharRecurso( Graphics g )
      {
         
       for (int cont=0;cont<rec_combo.getItemCount();cont++) 
        {
         recurso rec_ref =(recurso)rec_combo.getItemAt(cont);	
         rec_ref.y=this.getHeight()-50;
         rec_ref.x=cont*100+10;
         
         g.drawRoundRect( rec_ref.x,rec_ref.y-10,40, 40       ,20,20 );	
         g.drawString(rec_ref.toString(),rec_ref.x,rec_ref.y+50);
          
         
        }
      }
      
      public void desenharSetas ( Graphics g )
      {
      	 for (int cont=0;cont<proc_combo.getItemCount();cont++)
         {
      	  processo proc_ref=(processo)proc_combo.getItemAt(cont);
      	  if (!proc_ref.lista.isEmpty())
            for (int cont2=0;cont2<proc_ref.lista.size();cont2++) 
             {
              recurso rec_ref=(recurso)proc_ref.lista.get(cont2);
           
                g.setColor(Color.RED);
                g.drawLine(proc_ref.x+20,proc_ref.y+40,rec_ref.x+20,rec_ref.y-10);
              
                Polygon proc_seta = new Polygon();
                proc_seta.addPoint(rec_ref.x+20,rec_ref.y);
                proc_seta.addPoint(rec_ref.x+10,rec_ref.y-15);
                proc_seta.addPoint(rec_ref.x+20,rec_ref.y-10);
                proc_seta.addPoint(rec_ref.x+30,rec_ref.y-15);
              
                g.fillPolygon(proc_seta);
             
                g.setColor(Color.BLACK);
              }
         }
        for (int cont=0;cont<rec_combo.getItemCount();cont++) 
        {      
          recurso rec_ref =(recurso)rec_combo.getItemAt(cont);	
          if(!rec_ref.lista.isEmpty())
           {
              processo proc_ref=(processo)rec_ref.lista.get(0);
              
              g.setColor(Color.BLUE);
                           
              g.drawLine(rec_ref.x+20,rec_ref.y,proc_ref.x+20,proc_ref.y+50);
              
              Polygon rec_seta = new Polygon();
              rec_seta.addPoint(proc_ref.x+20,proc_ref.y+40);
              rec_seta.addPoint(proc_ref.x+10,proc_ref.y+55);
              rec_seta.addPoint(proc_ref.x+20,proc_ref.y+50);
              rec_seta.addPoint(proc_ref.x+30,proc_ref.y+55);
              
             
              g.fillPolygon(rec_seta);
              
              
              g.setColor(Color.BLACK);
             }
         }
      
      
      }
      
}