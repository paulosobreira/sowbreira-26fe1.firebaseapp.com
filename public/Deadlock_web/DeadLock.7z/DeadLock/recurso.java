package sowbreira.so.deadlock;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;


public class recurso extends listavel {

	public recurso(String in_nome,InfoPanel t)
	{
		super.nome=in_nome;
	    super.lista = new Vector();
	    super.output=t;
	}

    public synchronized boolean eliminavel(JComboBox ps,JComboBox rs)
    {
    if (ps.getItemCount()>0)
     for (int cont=0;cont<ps.getItemCount();cont++)	
        if ( ((listavel)ps.getItemAt(cont)).lista.contains(this) )
          {
      	    output.AddInfo("ERRO o recurso "+this+" N�o pode ser eliminado agora");
      	    //JOptionPane.showMessageDialog(null,"ERRO o recurso "+this+" N�o pode ser eliminado agora" ,"ERRO",JOptionPane.ERROR_MESSAGE);
          	return false;
          }
    
    if (!lista.isEmpty())
          {
          	output.AddInfo("ERRO o recurso "+this+" N�o pode ser eliminado agora");
          	//JOptionPane.showMessageDialog(null,"ERRO o recurso "+this+" N�o pode ser eliminado agora" ,"ERRO",JOptionPane.ERROR_MESSAGE);
          	return false;
          }          
    return true;
    }



}	