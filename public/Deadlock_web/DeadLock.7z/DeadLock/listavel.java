package sowbreira.so.deadlock;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;


public class listavel {
    private static boolean flag;
	private static Vector aux;
	public static String envolvidos; 
	public Vector lista;
	protected String nome;
    public InfoPanel output;
    public int  x,y;
			
	public listavel()
	{ aux=new Vector();}
	
	
	public void limpavar()
	{
      aux.clear();
	  envolvidos="";
	  flag=false;
    }
	
	
	public synchronized boolean deadlock(listavel origem,listavel corrente)
	{ 


	if (corrente instanceof processo)
	 
	 for (int cont=0;cont<corrente.lista.size();cont++)	
	  { 
	    if (origem == corrente )
	          {
	           /*if (!aux.contains(corrente.toString()))
	                {aux.add(corrente.toString());
	                 envolvidos+=" "+corrente+" ";}
	           output.AddInfo("Deadlock! Fechando Grafo em : "+origem+" Passando por "+envolvidos);
	           //JOptionPane.showMessageDialog(null,"Deadlock! Fechando Grafo em : "+origem+" Passando por "+envolvidos,"DEADLOCK DETECTADO",JOptionPane.INFORMATION_MESSAGE);*/
	           flag=true;
	           break;
	          }
	     else 
	       if (!(flag==true))  
	          {
	             if (!aux.contains(corrente.toString()))
	                {aux.add(corrente.toString());
	                 envolvidos+=" "+corrente+" ";}
	          flag=false;	
	          deadlock(origem,(listavel)corrente.lista.get(cont));
	          }
	  }
	
	else
	   if (origem == corrente.lista.get(0) )
	          {
	           output.AddInfo("Deadlock! Fechando Grafo em : "+origem+" Passando por "+envolvidos);
	           //JOptionPane.showMessageDialog(null,"Deadlock! Fechando Grafo em : "+origem+" Passando por "+envolvidos,"DEADLOCK DETECTADO",JOptionPane.INFORMATION_MESSAGE);
	           flag=true;
	          
	          }
	   else  
	       if (!(flag==true))
	         {
	          flag=false;	
	          deadlock(origem,(listavel)corrente.lista.get(0));
	          }

	 if (flag==true)
	   return true;
	  else 
	   return false;
	 } 
	
	
    public String toString()
    {return nome; }
}    	        