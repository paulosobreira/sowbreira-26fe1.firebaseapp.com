package sowbreira.so.deadlock;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.math.*;


public class processo extends listavel 
 								
   {
	public int Sde=1000,Sate=5000,Ude=100,Uate=500;
	
	public processo(String in_nome,InfoPanel t)
	{
		super.nome=in_nome;
	    super.lista = new Vector();
	    super.output=t;
	   
	 }	
	
  


	public synchronized boolean requer_recurso2(recurso rec)
	{
		super.limpavar();
        
       if (rec.lista.size()==10)
          return false;

		if (rec.lista.isEmpty())
		  {
		  	rec.lista.add(this);
		  	return true;
		   }	
		else
		  if (rec.lista.contains(this))
		    {
		     //JOptionPane.showMessageDialog(null,"O Processo "+this.nome+" J� esta de posse do Recurso ou J� esta na fila para obter "+rec,"ERRO",JOptionPane.ERROR_MESSAGE);
		    //output.AddInfo("O Processo "+this.nome+" J� esta de posse do Recurso ou J� esta na fila para obter "+rec); 
		    return false;
		    }
		  else
		    if (!deadlock(this,rec))
		       if (lista.contains(rec))
		        {
		        //output.AddInfo("O Processo "+this.nome+" J� esta na fila para obter "+rec);
		        //JOptionPane.showMessageDialog(null,"O Processo "+this.nome+" J� esta na fila para obter "+rec,"ERRO",JOptionPane.ERROR_MESSAGE);
		        return false;
		        }
		       else		    
		       {
		        this.lista.add(rec);
		        rec.lista.add(this);
		       return true;
		       } 
		 return false;
    }
   
   public void requer_recurso(recurso rec)
	{
		super.limpavar();

		if (rec.lista.isEmpty())
		  {
		  	rec.lista.add(this);
	
		   }	
		else
		  if (rec.lista.contains(this))
		    {
		     //JOptionPane.showMessageDialog(null,"O Processo "+this.nome+" J� esta de posse do Recurso ou J� esta na fila para obter "+rec,"ERRO",JOptionPane.ERROR_MESSAGE);
		    output.AddInfo("O Processo "+this.nome+" J� esta de posse do Recurso ou J� esta na fila para obter "+rec); 
	
		    }
		  else
		    if (!deadlock(this,rec))
		       if (lista.contains(rec))
		        {
		        output.AddInfo("O Processo "+this.nome+" J� esta na fila para obter "+rec);
		        //JOptionPane.showMessageDialog(null,"O Processo "+this.nome+" J� esta na fila para obter "+rec,"ERRO",JOptionPane.ERROR_MESSAGE);
	
		        }
		       else		    
		       {
		        this.lista.add(rec);
		        rec.lista.add(this);
	
		       } 
	
    }
   
   
   
   
   
   
   
   
   
   
   
   public void liberar_recurso(recurso rec)
	{ 
	 if(rec.lista.isEmpty())
	  output.AddInfo("O Processo "+this.nome+" N�o Possui o Recurso "+rec);
	  //JOptionPane.showMessageDialog(null,"O Processo "+this.nome+" N�o Possui o Recurso "+rec,"ERRO",JOptionPane.ERROR_MESSAGE);
	  else
	   if (rec.lista.get(0)==this)
	     {
	    
	      //removo a seta de requerimeto do recurso
	      if( rec.lista.size() > 1 )
	         {
	          processo p = (processo)rec.lista.get(1);
	          p.lista.remove(rec); 
	         }	

	      rec.lista.remove(this);
	     }
	   else
	     output.AddInfo("O Processo "+this.nome+" N�o Possui o Recurso "+rec);
	     //JOptionPane.showMessageDialog(null,"O Processo "+this.nome+" N�o Possui o Recurso "+rec,"ERRO",JOptionPane.ERROR_MESSAGE);
	     
	}
	
   public void setTempo(int x, int y , int z , int w)
   {	
	Sde=x;
	Sate=y;
    Ude=z;
    Uate=w;   
    output.AddInfo("O Processo "+this.nome+" solicitarara recursos No Intervalo de "+Sde+" ate "+Sate);
    output.AddInfo("O Processo "+this.nome+" usara seus recursos No Intervalo de "+Ude+" ate "+Uate);   
   
   }
   
   
	
	
   public void seMatar(JComboBox rs)
	{ 
    for (int cont=0;cont<rs.getItemCount();cont++)
	  {
	  listavel r =(listavel)rs.getItemAt(cont);
	   	for (int cont2=0;cont2<r.lista.size();cont2++)	
	      if(r.lista.get(cont2)==this)
	         {
	         if (cont2==0)
	          liberar_recurso((recurso)r);
	         r.lista.remove(this);	
	         
	         }
	  }
    }   
}

