package sowbreira.so.deadlock;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.math.*;


public class threads extends Thread
  
  
  { 
  
   private JComboBox recursos;
   public processo proc;
   private DrawPanel painel;
   public Vector rec_comp;
   private boolean usar_rec;
   public boolean vivo=true;
   
   public threads (processo p,JComboBox rec,DrawPanel pa)
   {recursos=rec;
    proc=p;
    painel=pa;
    rec_comp= new Vector();
   }
  
   public void run()
    {
     while(vivo) 
      {
      requer_recurso();
      liberarRec();
      }
    }
   
   private synchronized  void  requer_recurso()
   {
   	int qtd_rec_servico = 0+(int)(Math.random()*recursos.getItemCount());
   	int qtd_display = qtd_rec_servico + 1;
   	proc.output.AddInfo("O processo "+proc+" Precisa de "+qtd_display+" recursos parar finalizar seu servi�o");
   	while (rec_comp.size()<=qtd_rec_servico)
     	{
     	int random_rec = 0+(int)(Math.random()*recursos.getItemCount());
      	try { Thread.sleep(proc.Sde +(int)(Math.random()*proc.Sate));}
        catch( InterruptedException e ) 
           {System.err.println( e.toString() );}
        if (proc.requer_recurso2((recurso)recursos.getItemAt(random_rec)))
          {
          // proc.output.AddInfo("O processo "+proc+" Requisitou o recurso "+(recurso)recursos.getItemAt(random_rec));
           rec_comp.add(recursos.getItemAt(random_rec));  
           painel.repaint();
          }
        } 
    
    String rec_req=" ";
     for (int cont=0;cont<rec_comp.size();cont++) 
        {
         recurso rec_ref =(recurso)rec_comp.get(cont);
         rec_req +=rec_ref+" ";
       }
    proc.output.AddInfo("O processo "+proc+" Requisitou os recursos"+rec_req+"Parafinalizar o seu Servi�o");
             
   	while (usar_rec==false && !(rec_comp.size()==qtd_rec_servico))
   	 {
   	  for (int cont=0;cont<rec_comp.size();cont++) 
        {
         recurso rec_ref =(recurso)rec_comp.get(cont);
         if (!rec_ref.lista.isEmpty())
   	       if (rec_ref.lista.get(0)==proc)
   	         usar_rec=true;
           else
             {
             usar_rec=false;
             break;
             }
         try { Thread.sleep(proc.Sde +(int)(Math.random()*proc.Sate));}
            catch( InterruptedException e ) 
              {System.err.println( e.toString() );}             
   	     }     	 
   	 }
   	
   	
   }
    
   private synchronized void  liberarRec()
   {
   	 if (usar_rec==true)
   	  {
   	  	 String rec_lib=" ";
   	  	 for (int cont=0;cont<recursos.getItemCount();cont++) 
           {
            recurso rec_ref =(recurso)recursos.getItemAt(cont);
   	         if (!rec_ref.lista.isEmpty())
   	         if (rec_ref.lista.get(0)==proc)
   	          {
   	           try { Thread.sleep(proc.Ude +(int)(Math.random()*proc.Uate));}
                catch( InterruptedException e ) 
                  {System.err.println( e.toString() );}
   	           proc.liberar_recurso(rec_ref);	
   	           rec_comp.remove(rec_ref);
               rec_lib+=rec_ref+" ";
               painel.repaint();
              } 
           }
   
        proc.output.AddInfo("O processo "+proc+" Liberou os recursos "+rec_lib+"e Finalizou Seu Servi�o ");
        usar_rec=false;
     
       }    
    }  
}