package sowbreira.so.deadlock;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;


public class aplicativo extends JFrame {
	
    private ControlPanel controle;
	private DrawPanel painel;
	private InfoPanel info;
	private Controle2 C2;
	private int proc_cont,rec_cont;
	private Vector linhas;
	
	public aplicativo()
	{
	   super("Detector de DeadLocks");  
	   
	   getContentPane().setLayout(new BorderLayout(5,5));
	   
	   controle = new ControlPanel();
	   painel = new DrawPanel(controle.proc_combo,controle.rec_combo);
	   C2 = new Controle2();
	   info = new InfoPanel(C2);
	   
	   linhas = new Vector();
	   
	   getContentPane().add(controle,BorderLayout.NORTH);
	   
	   JScrollPane jp = new JScrollPane(painel);
	   jp.setHorizontalScrollBarPolicy(jp.HORIZONTAL_SCROLLBAR_ALWAYS);
	   //jp.setVerticalScrollBarPolicy(jp.VERTICAL_SCROLLBAR_ALWAYS);
	   //JViewport vp = jp.getViewport();
	   
	   getContentPane().add(jp,BorderLayout.CENTER);
	   getContentPane().add(info,BorderLayout.SOUTH);
	   
	   ligador();
       ligador2();	 
    }
    
    public void  ligador2()
    {   
     C2.Iniciar.addActionListener (new java.awt.event.ActionListener () {
        public void actionPerformed (java.awt.event.ActionEvent evt) 
        {
         
         controle.mata_proc.setEnabled(false);
         controle.mata_rec.setEnabled(false);
         
         
         if (!linhas.isEmpty())
         {
         for (int cont=0;cont<linhas.size();cont++)
           {
            threads th =(threads)linhas.get(cont);
            th.suspend();
           }
         linhas.removeAllElements();
         }
         
         for (int cont=0;cont<controle.proc_combo.getItemCount();cont++)
           {
           	processo proc_ref=(processo)controle.proc_combo.getItemAt(cont);
            threads th =new threads(proc_ref,controle.rec_combo,painel);
            linhas.add(th);
            th.start();
            
           }
        }
      });
     C2.Parar.addItemListener (new java.awt.event.ItemListener () {
        public synchronized void itemStateChanged( ItemEvent e )
        {
        if ( e.getStateChange() == ItemEvent.SELECTED )
         { 
          for (int cont=0;cont<linhas.size();cont++)
           {
            threads th =(threads)linhas.get(cont);
            th.suspend();
           }
        
         C2.Parar.setText("Threads em Pausa ");
         }
        else 
         { 
          for (int cont=0;cont<linhas.size();cont++)
           {
            threads th =(threads)linhas.get(cont);
            th.resume();
           }
         
         C2.Parar.setText("Pausa Threads");
         }
        }
      });
    C2.setupTempo.addActionListener (new java.awt.event.ActionListener () {
        public void actionPerformed (java.awt.event.ActionEvent evt) 
        {
         processo proc_ref=(processo)controle.proc_combo.getSelectedItem();
         proc_ref.setTempo(Integer.parseInt( C2.jTextField1.getText()),Integer.parseInt( C2.jTextField2.getText()),Integer.parseInt( C2.jTextField3.getText()),Integer.parseInt( C2.jTextField4.getText()));
        }
      });
    
    
    
    
    }
   
    public void  ligador()
    {
      controle.cria_proc.addActionListener (new java.awt.event.ActionListener () {
        public void actionPerformed (java.awt.event.ActionEvent evt) 
        {
         processo p = new processo("Processo :"+Integer.toString(proc_cont++),info);
         controle.proc_combo.addItem(p);
         painel.largura+=100;
         painel.repaint();
        }
      });
      
      controle.cria_rec.addActionListener (new java.awt.event.ActionListener () {
       public void actionPerformed (java.awt.event.ActionEvent evt) 
       {
       	 recurso r = new recurso("Recurso :"+Integer.toString(rec_cont++),info);
         controle.rec_combo.addItem(r);
         painel.largura+=100;
         painel.repaint();
       }
      });
      
      controle.req_recurso.addActionListener (new java.awt.event.ActionListener () {
        public void actionPerformed (java.awt.event.ActionEvent evt) 
        {
         
        ((processo)controle.proc_combo.getSelectedItem()).requer_recurso(((recurso)controle.rec_combo.getSelectedItem()));
         painel.repaint();
        
        }
      });

    
      controle.lib_recurso.addActionListener (new java.awt.event.ActionListener () {
        public void actionPerformed (java.awt.event.ActionEvent evt) 
        {
         processo proc_ref=(processo)controle.proc_combo.getSelectedItem();
         recurso rec_ref=(recurso)controle.rec_combo.getSelectedItem();
         proc_ref.liberar_recurso(rec_ref);
         
          for (int cont=0;cont<linhas.size();cont++)
           {
            threads th =(threads)linhas.get(cont);
             if (th.proc==proc_ref)
                 th.rec_comp.remove(rec_ref);
           }      
         
                
         painel.repaint();
        }
      });
    
     controle.mata_proc.addActionListener (new java.awt.event.ActionListener () {
        public void actionPerformed (java.awt.event.ActionEvent evt) 
        {
         if(controle.proc_combo.getItemCount()>0)
          {
           processo proc_ref=(processo)controle.proc_combo.getSelectedItem();
           proc_ref.seMatar(controle.rec_combo);
           controle.proc_combo.removeItem(proc_ref);
           proc_ref=null;
           painel.repaint();
          }
        }
      });
    
    controle.mata_rec.setText ("Mata Recurso");
    controle.mata_rec.addActionListener (new java.awt.event.ActionListener () {
        public void actionPerformed (java.awt.event.ActionEvent evt) 
        {
         if(controle.rec_combo.getItemCount()>0)
          {
          recurso rec_ref=(recurso)controle.rec_combo.getSelectedItem();
          if (rec_ref.eliminavel(controle.proc_combo,controle.rec_combo))
           {
            controle.rec_combo.removeItem(rec_ref);
            rec_ref=null;
           }
           painel.repaint(); 
          } 
        }
      });
    
    
    
    }

   public static void main( String args[] )
     {
       aplicativo app = new aplicativo();
       app.addWindowListener( new WindowAdapter()
       {
       	public void windowClosing(WindowEvent e)
	     { System.exit(0); }
       });
       Toolkit tk = app.getToolkit();
       Dimension dm = tk.getScreenSize(); 
       app.setSize(dm.width,(int)(dm.height/1.1));
       app.show();
       
     }
   

   
   
   }	   