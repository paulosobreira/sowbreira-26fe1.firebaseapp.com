
 **[SIBURADI](https://sowbreira-26fe1.firebaseapp.com/siburadi/siburadi.zip)**

## 

Sistema de busca rapida em diretorios

![](https://sowbreira-26fe1.firebaseapp.com/siburadi/pic1.jpg)

SIBURADI é um simples programa para visulaizar a localização de arquivos em qualquer tipo de dispositivo.

![](https://sowbreira-26fe1.firebaseapp.com/siburadi/pic2.jpg)

No menu avançado escolha criar "Nova Aba" para criar um grupo novo de arquivos. As informações serão salvas no diretório data com o nome digitado.

 ![](https://sowbreira-26fe1.firebaseapp.com/siburadi/pic3.jpg)

Na pasta raiz do gurpo pode ser acionado um dirtorio ou raiz de disco para catalogar. 

![](https://sowbreira-26fe1.firebaseapp.com/siburadi/pic4.jpg)

Após o catalogo ser criado o conteudo do mesmo aparece na janela da direita.

![](https://sowbreira-26fe1.firebaseapp.com/siburadi/pic5.jpg)

Nos diretorios de catalogos busca pode ser realizadas (F3 ou Menu->Procurar) a busca é feita buscando parte do nome nos diretorios percorrendo toda arvore.

![](https://sowbreira-26fe1.firebaseapp.com/siburadi/pic6.jpg)

Caso exitam mais ocorrencias estas são enfileiradas.

![](https://sowbreira-26fe1.firebaseapp.com/siburadi/pic7.jpg)

É possível também copiar e colar pastas atravéz dos catalogos.

 ![](https://sowbreira-26fe1.firebaseapp.com/siburadi/pic9.jpg)

Após qualquer alteração no grupo de catalagos, este deve ser salvo (F4 ou Menu->salvar) ou então salvar tudo com (F6).

[Baixar o SIBURADI.](https://sowbreira-26fe1.firebaseapp.com/siburadi/siburadi.zip)

