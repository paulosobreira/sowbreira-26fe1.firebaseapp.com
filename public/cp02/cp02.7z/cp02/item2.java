import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class item2 {
   private static int item = 0;
   private int max;
   
   public boolean buffer_cheio=false;
   public static boolean rc=false;
   public static Vector daVez;
  
   public item2(int val_item)
   {
   max=val_item;
   daVez = new Vector();
   }
   // metodo de incremento de item chamado pelo produtor
   public void inc()
   { 
     
      //seta a Rc 
      rc=true;
      daVez.remove(Thread.currentThread());
      
      //atualiza a interface grafica
      prods_staus(" **Regi�o Critica**\n");
      
      //metodo para simular processamento
      loops(deposito2.tempo2);
         
     //verifica a quantidade de itens em rela��o ao buffer      
     if (item<max) 
      { //incrementa a variavel compartilhada
      	item++;
       
       //atualiza a interface grafica
       deposito2.output.append("Produtor :"+ Thread.currentThread().getName() +
         " Produziu Item : " + item +
         " Prioridade :" + Thread.currentThread().getPriority() + "\n" );
       deposito2.status.setText(Integer.toString(item));  
       deposito2.output.setCaretPosition(deposito2.output.getText().length());
       
       prods_staus(" Pronto\n");
     
      //notifica todos os consumidores que est�o bloqueiados
      notifica_cons();   
      
      //sai da Rc
      rc = false;
      
      }
      else
      {
       //notifica todos os consumidores que est�o bloqueiados
       notifica_cons();
       //seta a se proprio como bloqueiado
       ((produtor2)Thread.currentThread()).bloqueado=true;
       //atualiza interface grafica
       prods_staus(" Bloqueado\n");
       //sai da Rc
       rc = false;
       }
   }
   // metodo de incremento de item chamado pelo produtor
   public void dec()
   {  //seta a Rc 
   	  rc=true;
      daVez.remove(Thread.currentThread());
       //atualiza a interface grafica
      cons_staus(" **Regi�o Critica**\n");
      
      //metodo para simular processamento
      loops(deposito2.tempo2);
      
      //verifica a quantidade de itens em rela��o ao buffer       
      if (item>0)
      {
      //atualiza a interface grafica
      deposito2.output.append("Consumidor :"+ Thread.currentThread().getName() +
      	  " Consumiu item :"+ item +
          " Prioridade :" + Thread.currentThread().getPriority()+ "\n");
      deposito2.output.setCaretPosition(deposito2.output.getText().length());
      //decrementa a variavel compartilhada
      item--;
      
       //atualiza a interface grafica
      deposito2.status.setText(Integer.toString(item)); 
      cons_staus("Pronto \n");
      
      //notifica todos os produtores que est�o bloqueiados 
      notifica_prods();
     
     //sai da RC
      rc = false;
      }
       else
      {
       //notifica todos os produtores que est�o bloqueiados 
       notifica_prods();
       //seta a se proprio como bloqueiado
       ((consumidor2)Thread.currentThread()).bloqueado=true; 
       cons_staus(" Bloqueado\n");
       //sai da RC
       rc = false;
      } 

   }
   
   private void prods_staus(String s)
      {
       //referencia para o thread atual
       produtor2 ref = (produtor2)Thread.currentThread();
       //seta o estado do thread atual
       ref.stado="Produtor["+Thread.currentThread().getPriority()+"] : "+ Thread.currentThread().getName() + s;
       deposito2.stado();
      }
   
   
    private void  cons_staus(String s)
      { 
      //referencia para o thread atual
      consumidor2 ref = (consumidor2)Thread.currentThread();
      //seta o estado do thread atual
      ref.stado="Consumidor["+Thread.currentThread().getPriority()+"] : "+ Thread.currentThread().getName() + s;
      deposito2.stado();
      }
    //metodo que notifica todos os consumidores que est�o bloqueiados 
    private void  notifica_cons()
      { 
          consumidor2 ref ;
          for (int cont=0;cont<deposito2.cons.size();cont++)
          { ref = (consumidor2)deposito2.cons.get(cont) ;
            if (ref.bloqueado==true) 
              ref.bloqueado=false;  
          } 	
      }
 //metodo que notifica todos os produtores que est�o bloqueiados      
    private void notifica_prods()
      {
    	produtor2 ref ;
         for (int cont=0;cont<deposito2.prods.size();cont++)
         { ref = (produtor2)deposito2.prods.get(cont) ;
             if (ref.bloqueado==true) 
             ref.bloqueado=false;  
         } 	
      }
         
      
   //metodo para simular processamento     
   private void loops(int x)
  {
  	for (int nada=0; nada<(x*1000000); nada++);
    for (int nada=0; nada<(x*1000000); nada++);
  } 
}

