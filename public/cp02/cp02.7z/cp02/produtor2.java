public class produtor2 extends Thread {
  private item2 ref_item;
  public boolean morto;
  public String stado;
  public boolean bloqueado;
   
   public produtor2 ( String f1,String f2,item2 i)
   {
      super(f1); 
      this.setPriority(Integer.parseInt(f2));
      ref_item=i;
   }


   public void run()
   { 
     //atualiza a interface grafica
     stado="Produtor["+getPriority()+"] : "+ getName() +" Iniciado\n";
     deposito2.stado();
     
     //roda enquanto vivo
     while (!morto)
     { //loop de espera ocupada quando bloqueiado
       if(!item2.daVez.contains(this))
         item2.daVez.add(this);
       
       while(bloqueado);
       
       
       //atualiza a interface grafica
       stado="Produtor["+getPriority()+"] : "+ getName() + " Pronto\n";
       deposito2.stado();
       
       //metodo para simular processamento
       loops(deposito2.tempo);
       
       //verifica se a Rc esta disponivel e n�o esta bloqueiado
       if (!item2.rc && (item2.daVez.get(0)==this) )
         ref_item.inc();
       else
         //loop em espera ocupada enquanto a RC estiver ocupada
         while (item2.rc);
         
        	
     }
    //atualiza a interface grafica
   deposito2.output.append("Produtor["+getPriority()+"] : "+ getName() +" Morreu\n");	         
   }
  //metodo para simular processamento 
  private void loops(int x)
  {
  	for (int nada=0; nada<(x*1000000); nada++);
    for (int nada=0; nada<(x*1000000); nada++);
  } 
     
}
