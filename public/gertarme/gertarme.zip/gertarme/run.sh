#!/bin/sh
java -Xms32M -Xmx32M br.nnpe.gertarme.view.MainWindow