java -cp bin:libs/* br.nnpe.cligen.MainFrame
