package sowbreira.redes.controle;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * @author Paulo
 */
public class ConverterArrayByte {
	
	private String msg;
	private Map arquivos;
	private ByteArrayInputStream inputStream;
	private int funcao;
	private int qtdeAnexos;
	private int tamMsg;
	
	/**
	 * @param inputStream
	 */
	public ConverterArrayByte(ByteArrayOutputStream out) throws Exception {
		this.inputStream = new ByteArrayInputStream(out.toByteArray());
		arquivos = new HashMap();
		convereter();
	}

	/**
	 * 
	 */
	private void convereter() throws Exception {
		//funcao = 1 byte
		//this.funcao = Util.byteArrayToInt(lerBytes(1));
		this.funcao = Util.byteArrayToInt(lerBytes(1));
		if(funcao==1)
			convereterSemAnexos();
		else
			convereterAnexos();
	}
	
	/**
	 * 
	 */
	private void convereterAnexos() throws Exception {
		//anexo 1 byte
		this.qtdeAnexos = Util.byteArrayToInt(lerBytes(1));
		//tamanho da mensagem = 2 bytes
		this.tamMsg = Util.byteArrayToInt(lerBytes(2));
		List nomeTamanhoArq = new ArrayList(); 
		for (int i = 0; i < qtdeAnexos; i++) {
			//tamanho do arquivo = 4 bytes
			//tamanho do nome do arquivo =1 byte
			nomeTamanhoArq.add(new TamanhoNomeArq(
					Util.byteArrayToInt(lerBytes(4)),
					Util.byteArrayToInt(lerBytes(1))));
		}
		//dados mensagem = x bytes
		this.msg = new String(lerBytes(tamMsg));
		for (Iterator iter = nomeTamanhoArq.iterator(); iter.hasNext();) {
			TamanhoNomeArq tamanhoNomeArq = (TamanhoNomeArq) iter.next();
			String nomeArquivo = new String(
					lerBytes(tamanhoNomeArq.getTamNomeArq()));
			arquivos.put(nomeArquivo,lerBytes(tamanhoNomeArq.getTamArq()));
			FileOutputStream fos =new FileOutputStream(new File(nomeArquivo));
			fos.write((byte[])arquivos.get(nomeArquivo));
			fos.close();
		}
		
	}
	
	private void convereterSemAnexos() throws Exception {
		//anexo 1 byte
		this.qtdeAnexos = Util.byteArrayToInt(lerBytes(1));
		//tamanho da mensagem = 2 bytes
		this.tamMsg = Util.byteArrayToInt(lerBytes(2));
		List nomeTamanhoArq = new ArrayList(); 
		//dados mensagem = x bytes
		this.msg = new String(lerBytes(tamMsg));

	}

	private byte[] lerBytes(int qtde) throws Exception{
		byte[] bs = new byte[qtde];
		for (int i = 0; i < qtde; i++) {
			int lido = inputStream.read();
			if (lido==-1)
				throw new Exception("Fim do buffer atingido");
			bs[i] = (byte) lido;
		}
		return bs;
	}

	public Map getArquivos() {
		return arquivos;
	}

	public String getMsg() {
		return msg;
	}
	private class TamanhoNomeArq{
		int tamArq;
		int tamNomeArq;
		
		/**
		 * @return Returns the tamArq.
		 */
		public int getTamArq() {
			return tamArq;
		}
		/**
		 * @param tamArq The tamArq to set.
		 */
		public void setTamArq(int tamArq) {
			this.tamArq = tamArq;
		}
		/**
		 * @return Returns the tamNomeArq.
		 */
		public int getTamNomeArq() {
			return tamNomeArq;
		}
		/**
		 * @param tamNomeArq The tamNomeArq to set.
		 */
		public void setTamNomeArq(int tamNomeArq) {
			this.tamNomeArq = tamNomeArq;
		}
		/**
		 * @param tamArq
		 * @param tamNomeArq
		 */
		public TamanhoNomeArq(int tamArq, int tamNomeArq) {
			super();
			this.tamArq = tamArq;
			this.tamNomeArq = tamNomeArq;
		}
	}
}
