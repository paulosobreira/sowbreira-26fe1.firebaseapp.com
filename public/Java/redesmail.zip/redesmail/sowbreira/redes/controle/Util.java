
package sowbreira.redes.controle;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * @author Ian
 */
public class Util
{
   /**
    * Converte um n�mero inteiro para uma representa��o em bytes. Retorna SEMPRE
    * um array de 4 bytes.
    */
   public static byte[] intToByteArray( int num )
   {
      //um int tem 4 bytes
      return numberToByteArray( num, 4 );
   }

   /**
    * Converte um n�mero short para uma representa��o em bytes. Retorna SEMPRE
    * um array de 2 bytes.
    */
   public static byte[] shortToByteArray( short num )
   {
      //short tem 2 bytes
      return numberToByteArray( num, 2 );
   }

   /* Faz a fun��o de converter um n�mero para uma representa��o em array de bytes, de acordo com o tamanho passado. */
   public static byte[] numberToByteArray( int num, int size )
   {
      String bits = Integer.toBinaryString( num );
      
      StringBuffer buf = new StringBuffer( size * 8 );
      //quantos bits faltam para o string que representa o inteiro completar 16
      int bitsLeft = size * 8 - bits.length();
      for( int i=0; i < bitsLeft; i++ )
      {
         buf.append('0');
      }
      buf.append( bits );
      
      byte[] binaryBytes = charsToByteArray( buf.toString().toCharArray() );
      
      return binaryBytesToStream( binaryBytes );
   }
   
   /** S� pra converter um n�mero para este ser representado num array de 3 bytes. */
   public static byte[] numberToThreeBytesArray( int num )
   {
      return numberToByteArray( num, 3 );
   }
   
   /** Para converter bytes que representem um short ou int para esse seu valor primitivo */
   public static int byteArrayToInt( byte[] bytes )
   {
      //primeiro, converte os bytes que representam o inteiro para bytes bin�rios
      byte[] binaryBytes = toBinaryBytes( bytes );
      
      //cria uma string que cont�m os bytes
      String binaryString = new String( bytesToCharArray( binaryBytes ) );
      
      return Integer.parseInt( binaryString, 2 );
   }
   
   /**
    * Conveni�ncia - converter array de chars para array de bytes, considerando que os chars s�o n�meros.
    * Precisa fazer isso porque o getBytes do String retorna os bytes de acordo com o unicode.
    */
   public static byte[] charsToByteArray( char[] chars )
   {
      byte[] bytes = new byte[ chars.length ];
      
      for( int i=0; i < bytes.length; i++ )
      {
         bytes[i] = (byte) Character.getNumericValue( chars[i] );
      }
      
      return bytes;
   }
   
   /**
    * Conveni�ncia - converter array de bytes para array de chars
    */
   public static char[] bytesToCharArray( byte[] bytes )
   {
      char[] chars = new char[ bytes.length ];
      
      for( int i=0; i < chars.length; i++ )
      {
         chars[i] = Character.forDigit( bytes[i], 10 );
      }
      
      return chars;
   }
   
   /**
    * Converte um array de bytes comuns para um array de bytes
    * s� de 0 ou 1, fazendo a equival�ncia bit a bit. Portanto, o
    * array retornado ser� sempre 8 vezes maior.
    * 
    * @param bytes Conjunto de bytes comuns.
    * @return array de valores 0 ou 1 
    */
   public static byte[] toBinaryBytes( byte[] bytes )
   {
      byte[] binaryBytes = new byte[ bytes.length * 8 ];
      
      //�ndice para contar quantas opera��es de bit foram feitas (que � = ao total de bits)
      int sumIndex = 0;
      for( int i=0; i < bytes.length; i++ )
      {
         //byte comum, tempor�rio
         byte tmpByte = bytes[i];
         
         for( int j=0; j < 8; j++ )
         {
            //vai deslocando os bits pra pegar o MSB
            if ( j!=0 )
               tmpByte = ( byte ) ( tmpByte << 1 );
            
            //se � 10000000, fica 1, qualquer outra coisa � 0.
            binaryBytes[ sumIndex ] = ( ( tmpByte & -128 ) == -128 ) ? (byte)1 : (byte)0; 
            
            sumIndex++;
         }
      }
      
      return binaryBytes;
   }

   /**
    * Converte um array de bytes bin�rios (0 ou 1) para um
    * array de bytes comuns (um stream).
    * 
    * @param binaryBytes Conjunto de bytes 0 ou 1.
    * @return bytes convertidos. � sempre 8 vezes menor. 
    */
   public static byte[] binaryBytesToStream( byte[] binaryBytes )
   {
      byte[] bytes = new byte[ binaryBytes.length / 8 ];
      
      int j = 7;
      int sumIndex = 0;
      byte generatedByte = 0;
      for( int i=0; i < binaryBytes.length; i++ )
      {
         byte tmpByte = binaryBytes[i];
         
         //vai acrescentando os bits pegos no byte a ser retornando
         generatedByte |= tmpByte << j;
         
         //a cada 8 bytes bin�rios, temos um byte comum 
         if( j == 0 )
         {
            bytes[ sumIndex++ ] = generatedByte;
            generatedByte = 0;
            j=7;
            continue;
         }
         
         j--;
      }
      
      return bytes;
   }
   
   
   // Returns the contents of the file in a byte array.
   public static byte[] getBytesFromFile(File file) throws IOException {
       InputStream is = new FileInputStream(file);
   
       // Get the size of the file
       long length = file.length();
   
       // You cannot create an array using a long type.
       // It needs to be an int type.
       // Before converting to an int type, check
       // to ensure that file is not larger than Integer.MAX_VALUE.
       if (length > Integer.MAX_VALUE) {
           // File is too large
       }
   
       // Create the byte array to hold the data
       byte[] bytes = new byte[(int) length];
   
       // Read in the bytes
       int offset = 0;
       int numRead = 0;
       while (offset < bytes.length
              && (numRead=is.read(bytes, offset, bytes.length-offset)) >= 0) {
           offset += numRead;
       }
   
       // Ensure all the bytes have been read in
       if (offset < bytes.length) {
           throw new IOException("Could not completely read file "+file.getName());
       }
   
       // Close the input stream and return bytes
       is.close();
       return bytes;
   }
   
   public static byte[] textToNumberArray(String tmpDestino)
   {
       byte destino[] = new byte[4];
       
       for( int i = 0; i < 4 ;i++ )
       {
           String bt;
           try {
               bt = tmpDestino.substring( 0, tmpDestino.indexOf(".") );
           } catch (StringIndexOutOfBoundsException ex) {
               bt = tmpDestino.substring( 0 );
           }

           destino[i] = Util.numberToByteArray( Integer.parseInt( bt ), 1 )[0];
           tmpDestino = tmpDestino.substring( tmpDestino.indexOf(".") + 1 );
       }
       
       return destino;
   }

    /**
     * @param dados
     */
    public static void show(byte[] dados) {

        for ( int i = 0; i < dados.length ;i++ )
        {
            System.out.print( dados[i] + " " );
        }

    }
   
}
