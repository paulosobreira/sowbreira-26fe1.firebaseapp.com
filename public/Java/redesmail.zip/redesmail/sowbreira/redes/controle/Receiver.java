package sowbreira.redes.controle;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

import sowbreira.redes.visao.EmailApp;
import sowbreira.redes.visao.InfoClass;

/**
 * @author Paulo
 */
public class Receiver extends Thread{

	private int packageSize,porta;
	private ServerSocket srv;
	private Socket cliente;
	private ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
	private EmailApp app;
	public void run(){
        try {
            while(true){
	        	cliente = srv.accept();
	        	byte[] prePacotes = new byte[4];
	        	cliente.getInputStream().read(prePacotes);
	        	int numPacotes = Util.byteArrayToInt(prePacotes);
	        	InfoClass.imprimir("Recebendo  "+ numPacotes+" pacotes.");
	        	cliente.getInputStream().read(prePacotes);
	        	int tamPacotes = Util.byteArrayToInt(prePacotes);
	        	InfoClass.imprimir(
	        			"Tamanho dos Pacotes :"+ tamPacotes+" bytes");
	        	byte[] pacotes = new byte[tamPacotes];
	        	int i = 0;
	        	DataInputStream inputStream = new DataInputStream(
	        			cliente.getInputStream());
	    		InfoClass.setaBarra(numPacotes);
	        	while (i<numPacotes) {
	        		inputStream.readFully(pacotes);
	            	outputStream.write(pacotes);
					InfoClass.imprimirPacotes("Recebido Pacote "+(i++)+" : "
							+pacotes.length+" bytes");
					InfoClass.setaBarraProgresso(i);
				}
	        	InfoClass.imprimir("Tamanho do array de bytes recebidos" + 
	        			outputStream.toByteArray().length);
	        	InfoClass.imprimir("Quantidade de pacotes  recebidos : " + 
	        			i);
	        	app.recebimentoConclido();
            }
        }
         catch ( Exception e ) {
         	e.printStackTrace(); 
         }
     }
	
	/**
	 * @param pacotes
	 * @param tamPacotes
	 * @return
	 */
	private byte[] filtraPacote(byte[] pacotes, int tamPacotes) {
		byte[] retorno = new byte[tamPacotes];
		for (int i = 0; i < tamPacotes; i++) {
			retorno[i]=pacotes[i];
		}
		return retorno;
	}

	/**
	 * @param packageSize
	 */
	public Receiver(int packageSize,int porta,EmailApp app) {
		super();
		this.packageSize = packageSize;
		this.porta = porta;
		this.app = app;
		try {
            srv = new java.net.ServerSocket( porta );
            InfoClass.imprimir("Ok eu sou "+InetAddress.getLocalHost() +
            				 " ouvindo na porta "+srv.getLocalPort()+"\n");
            srv.setReceiveBufferSize(packageSize);
            this.start();
         }
         catch( Exception e ) {
             e.printStackTrace();
         }
	}
	
	public void desliga(){
		try {
			srv.close();
			this.interrupt();
		} catch (IOException e) {
			InfoClass.imprimir(e.getMessage());
		}
	}
	/**
	 * @return Returns the outputStream.
	 */
	public ByteArrayOutputStream getOutputStream() {
		return outputStream;
	}
}
