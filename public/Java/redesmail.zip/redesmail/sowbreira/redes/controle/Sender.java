package sowbreira.redes.controle;
import java.io.ByteArrayInputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import sowbreira.redes.visao.InfoClass;

/**
 * @author Paulo
 *
 */
public class Sender extends Thread{

	private Socket cliente;
	private int packageSize,porta;
	private byte[] dados;
	private List pacotes = new ArrayList();
	private ByteArrayInputStream inputStream;
	public void run(){
        try {
        	enviarDados();
        }
         catch ( Exception e ) {
         	e.printStackTrace(); }
     }
	/**
	 * @param packageSize
	 * @param porta
	 */
	public Sender(String destino,
        int packageSize, int porta, byte[] dados) throws Exception {
		super();
    	cliente = new Socket(destino,porta);
		this.dados = dados;
		this.packageSize = packageSize;
		this.porta = porta;
		this.inputStream = new ByteArrayInputStream(dados);
		this.start();
	}

	private void enviarDados() throws Exception {
		int numPacotes = (int) Math.ceil(dados.length/(double)packageSize);
		InfoClass.imprimir("Tamanho do do Array de bytes :" +dados.length);  
		InfoClass.imprimir("Tamanho do Pacote :"+packageSize);
		InfoClass.imprimir("Enviando "+numPacotes+" Pacotes.");
		Thread.sleep(1500);
		//enviando num e tam de pacotes 8bytes;
		cliente.getOutputStream().write(Util.intToByteArray(numPacotes));
		cliente.getOutputStream().write(Util.intToByteArray(packageSize));
		InfoClass.setaBarra(numPacotes);
		int qdePaotes = 0;
		for (int i = 0; i < numPacotes; i++) {
			byte[] bs = lerBytes(packageSize);
			InfoClass.imprimirPacotes("Enviando pacote : "+i+" "+bs.length+"bytes");
			cliente.getOutputStream().write(bs);
			InfoClass.setaBarraProgresso(i);
			qdePaotes = i;
		}
    	InfoClass.imprimir("Quantidade de pacotes enviados : " + 
    			qdePaotes);
        InfoClass.setaBarraProgressoFim();
	}
	public static void main(String[] args) {
		System.out.println(Math.ceil((214/(double)10)));
	}
	private byte[] lerBytes(int qtde) throws Exception{
		byte[] bs = new byte[qtde];
		for (int i = 0; i < qtde; i++) {
			int lido = inputStream.read();
			if (lido==-1)
				bs[i] =(byte)0;
			bs[i] = (byte) lido;
		}
		return bs;
	}
}