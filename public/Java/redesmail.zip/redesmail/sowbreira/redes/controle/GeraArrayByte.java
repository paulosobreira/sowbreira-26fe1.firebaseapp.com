package sowbreira.redes.controle;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.Iterator;
import java.util.Map;
/**
 * @author Paulo
 * Created on 30/10/2004
 *
 */
public class GeraArrayByte {
	private int funcao;
	private int qtdeAnexos;
	private int tamMsg;
	private int tamArq;
	private int tamNomeArq;
	private String msg;
    private ByteArrayOutputStream out = new ByteArrayOutputStream();

        /**
	 * @param funcao
	 * @param qtdeAnexos
	 * @param msg
	 */
	public GeraArrayByte(int funcao, int qtdeAnexos, String msg) {
		super();
		this.funcao = funcao;
		this.qtdeAnexos = qtdeAnexos;
		this.msg = msg;
		this.tamMsg = msg.length();
	}
        
    public ByteArrayOutputStream gerar(Map arquivos) throws Exception{
    	//funcao = 1 byte
    	out.write(Util.numberToByteArray(funcao,1));
    	//anexo 1 byte
    	this.qtdeAnexos = arquivos.size();
    	out.write(Util.numberToByteArray(qtdeAnexos,1));
    	//tamanho da mensagem = 2 bytes
    	out.write(Util.numberToByteArray(tamMsg,2));
    	//para evitar 2 loops
    	ByteArrayOutputStream outAux = new ByteArrayOutputStream();
    	//loop pelos arquivos
    	for (Iterator iter = arquivos.keySet().iterator(); iter.hasNext();) {
                String arqNome = (String) iter.next();
                File file = (File) arquivos.get(arqNome); 
                byte[] fileB = Util.getBytesFromFile(file); 
                tamArq = fileB.length;
                //tamanho do arquivo = 4 bytes
                out.write(Util.numberToByteArray(tamArq,4));
                //tamanho do nome do arquivo =1 byte
                out.write(Util.numberToByteArray(arqNome.length(),1));
                
                //parte final usado o buffer auxiliar
                //nome do arquivo = y bytes
                outAux.write(arqNome.getBytes());
                //dados do arquivo= z bytes
                outAux.write(fileB);
        }            
    	//dados mensagem = x bytes
    	out.write(msg.getBytes());
    	//concatenado ao fim do arquivo os nomes e dados dos arquivos
    	out.write(outAux.toByteArray());
        return out;
    }
        
        
	/**
	 * @return Returns the funcao.
	 */
	public int getFuncao() {
		return funcao;
	}
	/**
	 * @param funcao The funcao to set.
	 */
	public void setFuncao(int funcao) {
		this.funcao = funcao;
	}
	/**
	 * @return Returns the msg.
	 */
	public String getMsg() {
		return msg;
	}
	/**
	 * @param msg The msg to set.
	 */
	public void setMsg(String msg) {
		this.msg = msg;
	}
	/**
	 * @return Returns the out.
	 */
	public ByteArrayOutputStream getOut() {
		return out;
	}
	/**
	 * @param out The out to set.
	 */
	public void setOut(ByteArrayOutputStream out) {
		this.out = out;
	}
	/**
	 * @return Returns the qtdeAnexos.
	 */
	public int getQtdeAnexos() {
		return qtdeAnexos;
	}
	/**
	 * @param qtdeAnexos The qtdeAnexos to set.
	 */
	public void setQtdeAnexos(int qtdeAnexos) {
		this.qtdeAnexos = qtdeAnexos;
	}
	/**
	 * @return Returns the tamArq.
	 */
	public int getTamArq() {
		return tamArq;
	}
	/**
	 * @param tamArq The tamArq to set.
	 */
	public void setTamArq(int tamArq) {
		this.tamArq = tamArq;
	}
	/**
	 * @return Returns the tamMsg.
	 */
	public int getTamMsg() {
		return tamMsg;
	}
	/**
	 * @param tamMsg The tamMsg to set.
	 */
	public void setTamMsg(int tamMsg) {
		this.tamMsg = tamMsg;
	}
	/**
	 * @return Returns the tamNomeArq.
	 */
	public int getTamNomeArq() {
		return tamNomeArq;
	}
	/**
	 * @param tamNomeArq The tamNomeArq to set.
	 */
	public void setTamNomeArq(int tamNomeArq) {
		this.tamNomeArq = tamNomeArq;
	}
}
