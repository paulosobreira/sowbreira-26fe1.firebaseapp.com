/*
 * Created on 31/10/2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package sowbreira.redes.visao;

import java.util.LinkedList;

/**
 * @author Paulo
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class Atualizador extends Thread{
	
    public static LinkedList fila = new LinkedList();
        /* (non-Javadoc)
         * @see java.lang.Runnable#run()
     */
    public void run() {
        while (true){
                try {
                        sleep(20);
                } catch (InterruptedException e) {
                        e.printStackTrace();
                }
                if (!fila.isEmpty() && InfoClass.mostrarTrafego()){
                        String s = (String) fila.removeFirst();
                        EmailApp.infoArea.append(s+"\n");
                        EmailApp.infoArea.setCaretPosition(
                                        EmailApp.infoArea.getText().length());
                }
        }
    }
		
    public synchronized static void  add(Object o){
            fila.add(o);
    }
    /**
     * 
     */
    public Atualizador() {
            start();
    }
}
