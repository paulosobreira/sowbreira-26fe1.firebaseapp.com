/*
 * Created on 30/10/2004
 *
 * */
package sowbreira.redes.visao;


/**
 * @author Paulo
 */
public class InfoClass {
	

    private static Atualizador atualizador = new Atualizador();

    public static void imprimir(String s){
                //System.out.println(s);
		EmailApp.InfoArea2.append(s+"\n");
		EmailApp.InfoArea2.setCaretPosition(
				EmailApp.InfoArea2.getText().length());
	}
	public static void imprimirPacotes(String s){
		if (mostrarTrafego()){
			EmailApp.infoArea.append(s+"\n");
	        EmailApp.infoArea.setCaretPosition(
	                        EmailApp.infoArea.getText().length());
		}
/*		if (mostrarTrafego()) 
                  Atualizador.add(s);*/
	}
	
	public static void setaBarra(int i){
		EmailApp.jProgressBar1.setMaximum(i);
	}
	public static void setaBarraProgresso(int i){
		EmailApp.jProgressBar1.setValue(i);
	}
	public static void setaBarraProgressoFim(){
	    EmailApp.jProgressBar1.setValue(
	        EmailApp.jProgressBar1.getMaximum());
	}
	
	public static boolean mostrarTrafego(){
	    //return true;
	    return EmailApp.jCheckBox1.isSelected();
	}
	
}
