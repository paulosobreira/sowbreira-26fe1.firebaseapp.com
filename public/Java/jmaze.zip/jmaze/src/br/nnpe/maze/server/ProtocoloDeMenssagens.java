/*
 * Created on 17/03/2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package br.nnpe.maze.server;

/**
 * @author sobreira
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class ProtocoloDeMenssagens {
	public static final String SEPARADOR="|";
	public static final String NOME="NOME";
	public static final String MSG="MSG";
	public static final String VEZ="VEZ";
	public static final String MOVER_CIMA="MOVER_CIMA";
	public static final String MOVER_BAIXO="MOVER_BAIXO";
	public static final String MOVER_ESQUERDA="MOVER_ESQUERDA";
	public static final String MOVER_DIREITA="MOVER_DIREITA";
	public static final String MOVER="MOVER";
	public static final String INICIAR_LABIRINTO="INICIAR_LABIRINTO";
	public static final String ENVIAR_LABIRINTO="ENVIAR_LABIRINTO";
	public static final String ENVIAR_LISTA_JOGADORES="ENVIAR_LISTA_JOGADORES";
	public static final String ENVIAR_PONTO_ORIGEM="ENVIAR_PONTO_ORIGEM";
	public static final String FIM_DO_JOGO="FIM_DO_JOGO";
	public static final String DESCONECTAR="DESCONECTAR";
	public static final String BEEP="99";
}
