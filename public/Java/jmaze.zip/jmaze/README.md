# jmaze
Jogo do labirinto

Compile na IDE e execute:
java -cp .:lib/* br.nnpe.maze.MazeGame
