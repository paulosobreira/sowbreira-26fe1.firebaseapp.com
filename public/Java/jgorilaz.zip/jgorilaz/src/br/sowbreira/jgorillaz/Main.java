package br.sowbreira.jgorillaz;

public class Main {

	public static void main(String[] args) throws InterruptedException {
		GorillazFrame frame = new GorillazFrame();
		frame.show();
	}
}
