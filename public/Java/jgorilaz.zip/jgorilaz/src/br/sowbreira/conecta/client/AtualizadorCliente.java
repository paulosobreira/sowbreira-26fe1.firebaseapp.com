package br.sowbreira.conecta.client;

/**
 * @author sobreira
 * Created on 18/06/2004
 */
public interface AtualizadorCliente {
	public void atualizaCliente(); 
}
