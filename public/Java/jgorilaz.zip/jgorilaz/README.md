# jgorilaz
Jogo de balística


Compilar na IDE e executar 

br.sowbreira.jgorillaz.Main
