package algoritmo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class Poupador extends ProgramaPoupador {
	private int[] cimaArr = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
	private int[] esquerdaArr = new int[] { 0, 1, 5, 6, 10, 11, 14, 15, 19, 20 };
	private int[] direitaArr = new int[] { 3, 4, 8, 9, 12, 13, 17, 18, 22, 23 };
	private int[] baixoArr = new int[] { 14, 15, 16, 17, 18, 19, 20, 21, 22, 23 };

	private int[] cimaOftArr = new int[] { 0, 1, 2 };
	private int[] esquerdaOftArr = new int[] { 0, 3, 5 };
	private int[] direitaOftArr = new int[] { 2, 4, 7 };
	private int[] baixoOftArr = new int[] { 5, 6, 7 };

	public int acao() {
		int[] visao = sensor.getVisaoIdentificacao();
		int[] ofPop = sensor.getAmbienteOlfatoPoupador();
		int[] ofLadrao = sensor.getAmbienteOlfatoLadrao();
		int[] posis = new int[4];
		// imprimiVisao(visao);
		posis[0] = quantificaMovimento(visao, ofPop, ofLadrao, cimaArr,
				cimaOftArr);
		posis[3] = quantificaMovimento(visao, ofPop, ofLadrao, esquerdaArr,
				esquerdaOftArr);
		posis[2] = quantificaMovimento(visao, ofPop, ofLadrao, direitaArr,
				direitaOftArr);
		posis[1] = quantificaMovimento(visao, ofPop, ofLadrao, baixoArr,
				baixoOftArr);
		List list = new ArrayList();
		int valMaior = Integer.MIN_VALUE;
		for (int i = 0; i < posis.length; i++) {
			if (valMaior <= posis[i]) {
				valMaior = posis[i];
			}
		}
		for (int i = 0; i < posis.length; i++) {
			if (valMaior == posis[i]) {
				list.add(new Integer(i));
			}
		}

		Collections.shuffle(list);
		int indiceIr = ((Integer) list.get(0)).intValue() + 1;
		switch (indiceIr) {
		case 1:
			if (verificaPodeIr(visao[7])) {
				return indiceIr;
			}
			break;
		case 2:
			if (verificaPodeIr(visao[16])) {
				return indiceIr;
			}
			break;
		case 3:
			if (verificaPodeIr(visao[12])) {
				return indiceIr;
			}
			break;
		case 4:
			if (verificaPodeIr(visao[11])) {
				return indiceIr;
			}
			break;
		default:
			break;
		}
		return selecionaIntervalo(visao, 1, 4);
	}

	private void imprimiVisao(int[] visao) {
		int cont = 0;

		for (int i = 0; i < visao.length; i++) {

			if (cont % 5 == 0) {
				System.out.println();
			}
			if (i == 12) {
				System.out.print("  ");
				System.out.print("*" + visao[i]);
				cont++;
				cont++;
			} else {
				System.out.print("*" + visao[i]);
				cont++;
			}
		}
		System.out.println();
		System.out.println("=========================");
	}

	private int quantificaMovimento(int[] visao, int[] ofatoPopador,
			int[] ofatoLadrao, int[] destArray, int[] oftArray) {
		int retorno = 0;
		for (int i = 0; i < destArray.length; i++) {
			int qtdePos = visao[destArray[i]];
			if (qtdePos >= 100 && qtdePos <= 200) {
				retorno -= 10;
			} else if (qtdePos >= 200) {
				retorno -= visao[destArray[i]];
			} else if (qtdePos == 4) {
				retorno += 30;
			} else if (qtdePos == 3 && sensor.getNumeroDeMoedas() > 10) {
				retorno += 100;
			}
		}
		for (int i = 0; i < oftArray.length; i++) {
			int qdtofato = ofatoPopador[oftArray[i]];
			int qdtofatoLadrao = ofatoLadrao[oftArray[i]];
			if (qdtofato > 0) {
				retorno -= ((6 - qdtofato) * 5);
			}
			if (qdtofatoLadrao > 0) {
				retorno -= ((10 - qdtofatoLadrao) * 10);
			}
		}
		retorno -= quantificaPassoImendiato(visao, destArray);
		return retorno;
	}

	private int quantificaPassoImendiato(int[] visao, int[] destArray) {
		if (destArray == cimaArr) {
			return verificaNaoPodeIr(visao[7]);
		}
		if (destArray == baixoArr) {
			return verificaNaoPodeIr(visao[16]);
		}
		if (destArray == esquerdaArr) {
			return verificaNaoPodeIr(visao[11]);
		}
		if (destArray == direitaArr) {
			return verificaNaoPodeIr(visao[12]);
		}
		return 0;
	}

	public int selecionaIntervalo(int[] visao, int intervalo1, int intervalo2) {
		int pos = (int) (intervalo1 + Math.random()
				* (intervalo2 - intervalo1 + 1));
		boolean moviMentoValido = false;
		int cont = 0;
		while (!moviMentoValido) {
			cont++;
			if (cont > 10) {
				break;
			}
			switch (pos) {
			case 1:
				if (verificaPodeIr(visao[7])) {
					moviMentoValido = true;
				}
				break;
			case 2:
				if (verificaPodeIr(visao[16])) {
					moviMentoValido = true;
				}
				break;
			case 3:
				if (verificaPodeIr(visao[12])) {
					moviMentoValido = true;
				}
				break;
			case 4:
				if (verificaPodeIr(visao[11])) {
					moviMentoValido = true;
				}
				break;
			default:
				break;
			}
			if (!moviMentoValido) {
				pos = (int) (intervalo1 + Math.random()
						* (intervalo2 - intervalo1 + 1));
			}
		}
		return pos;
	}

	private int verificaNaoPodeIr(int i) {
		if (i == -2 || i == -1 || i == 1 || i >= 100
				|| (i == 5 && sensor.getNumeroDeMoedas() < 5)) {
			return 50;
		}

		return 0;
	}

	private boolean verificaPodeIr(int val) {
		return verificaNaoPodeIr(val) == 0;
	}

}
