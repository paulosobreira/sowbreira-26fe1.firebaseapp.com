package algoritmo;

public class PoupadorAleatorio extends ProgramaPoupador {

	public int acao() {
		
/*//		Percebendo valores do ambiente
		sensor.getVisaoIdentificacao();
		sensor.getAmbienteOlfatoLadrao();
		sensor.getAmbienteOlfatoPoupador();
		sensor.getNumeroDeMoedas();
		sensor.getNumeroDeMoedasBanco();
		sensor.getNumeroJogadasImunes();
		sensor.getPosicao();*/
		
		return selecionaIntervalo(0, 4);
	}

	public int selecionaIntervalo(int intervalo1, int intervalo2) {
		return (int) (intervalo1 + Math.random()
				* (intervalo2 - intervalo1 + 1));
	}

}
