package algoritmo;

import java.awt.Point;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Ladrao extends ProgramaLadrao {

	private int[] cimaArr = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
	private int[] esquerdaArr = new int[] { 0, 1, 5, 6, 10, 11, 14, 15, 19, 20 };
	private int[] direitaArr = new int[] { 3, 4, 8, 9, 12, 13, 17, 18, 22, 23 };
	private int[] baixoArr = new int[] { 14, 15, 16, 17, 18, 19, 20, 21, 22, 23 };

	private int[] cimaOftArr = new int[] { 0, 1, 2 };
	private int[] esquerdaOftArr = new int[] { 0, 3, 5 };
	private int[] direitaOftArr = new int[] { 2, 4, 7 };
	private int[] baixoOftArr = new int[] { 5, 6, 7 };

	private boolean modoDesespero;
	private int qdtdeTempo;
	private int ultMovimento;
	private Point ultPonto;
	private int contPreso;
	private Map mapaNosVisitados = new HashMap();
	private int indexMuitoVisitado = 5;

	public int acao() {
		qdtdeTempo++;
		if (qdtdeTempo > 300 && sensor.getNumeroDeMoedas() == 0) {
			modoDesespero = true;
		}

		if (ultPonto != null && sensor.getPosicao() != null
				&& ultPonto.x == sensor.getPosicao().x
				&& ultPonto.y == sensor.getPosicao().y) {
			contPreso++;
		}
		ultPonto = sensor.getPosicao();
		incrementarNosVistados(ultPonto);

		int[] visao = sensor.getVisaoIdentificacao();
		int[] ofPop = sensor.getAmbienteOlfatoPoupador();
		int[] ofLadrao = sensor.getAmbienteOlfatoLadrao();

		imprimiVisao(visao);
		if (contPreso > 5) {
			contPreso = 0;
			ultMovimento = 0;
			return selecionaIntervalo(visao, 1, 4);
		}
		int[] posis = new int[4];
		posis[0] = quantificaMovimento(visao, ofPop, ofLadrao, cimaArr,
				cimaOftArr);
		posis[3] = quantificaMovimento(visao, ofPop, ofLadrao, esquerdaArr,
				esquerdaOftArr);
		posis[2] = quantificaMovimento(visao, ofPop, ofLadrao, direitaArr,
				direitaOftArr);
		posis[1] = quantificaMovimento(visao, ofPop, ofLadrao, baixoArr,
				baixoOftArr);
		List list = new ArrayList();
		int valMaior = Integer.MIN_VALUE;
		for (int i = 0; i < posis.length; i++) {
			if (valMaior <= posis[i]) {
				valMaior = posis[i];
			}
		}
		for (int i = 0; i < posis.length; i++) {
			if (valMaior == posis[i]) {
				list.add(new Integer(i));
			}
		}
		if (!verificaVerPoupador(visao) && verificaSemOlfato(ofPop)
				&& valMaior < 20) {
			return selecionaIntervalo(visao, 1, 4);
		}
		Collections.shuffle(list);
		int indiceIr = ((Integer) list.get(0)).intValue() + 1;
		if (!verificaNoMuitoVisitado(indiceIr)) {
			switch (indiceIr) {
			case 1:
				if (verificaPodeIr(visao[7])) {
					ultMovimento = indiceIr;
					return indiceIr;
				}
				break;
			case 2:
				if (verificaPodeIr(visao[16])) {
					ultMovimento = indiceIr;
					return indiceIr;
				}
				break;
			case 3:
				if (verificaPodeIr(visao[12])) {
					ultMovimento = indiceIr;
					return indiceIr;
				}
				break;
			case 4:
				if (verificaPodeIr(visao[11])) {
					ultMovimento = indiceIr;
					return indiceIr;
				}
				break;
			default:
				break;
			}
		}
		return selecionaIntervalo(visao, 1, 4);

	}

	private void incrementarNosVistados(Point ultPonto2) {
		Integer integer = (Integer) mapaNosVisitados.get(ultPonto2);
		if (integer == null) {
			mapaNosVisitados.put(ultPonto2, new Integer(1));
		} else {
			mapaNosVisitados
					.put(ultPonto2, new Integer(integer.intValue() + 1));
		}

	}

	private boolean verificaSemOlfato(int[] ofPop) {
		for (int i = 0; i < ofPop.length; i++) {
			if (ofPop[i] > 0) {
				return false;
			}
		}
		return true;
	}

	private boolean verificaVerPoupador(int[] visao) {
		for (int i = 0; i < visao.length; i++) {
			if (visao[i] >= 100 && visao[i] < 200) {
				return true;
			}
		}
		return false;
	}

	private int quantificaMovimento(int[] visao, int[] ofatoPopador,
			int[] ofatoLadrao, int[] destArray, int[] oftArray) {
		int retorno = 0;
		for (int i = 0; i < destArray.length; i++) {
			int qtdePos = visao[destArray[i]];
			if (qtdePos >= 200 && modoDesespero) {
				if (visao[7] < 200 && visao[16] < 200 && visao[11] < 200
						&& visao[12] < 200)
					retorno += 50;
			}
			if (qtdePos >= 100 && qtdePos < 200) {
				retorno += 100;
			}
			if (qtdePos == 3) {
				retorno += 10;
			}
			// if (qtdePos == 4) {
			// retorno += 2;
			// }
		}
		for (int i = 0; i < oftArray.length; i++) {
			int qdtofato = ofatoPopador[oftArray[i]];
			int qdtofatoLadrao = ofatoLadrao[oftArray[i]];
			if (qdtofato > 0) {
				retorno += ((20 - qdtofato) * 10);
			}
			if (modoDesespero && qdtofatoLadrao > 0) {
				if (visao[7] < 200 && visao[16] < 200 && visao[11] < 200
						&& visao[12] < 200)
					retorno += ((10 - qdtofatoLadrao) * 2);
			}
		}
		// retorno -= quantificaPassoImendiato(visao, destArray);
		return retorno;
	}

	private int quantificaPassoImendiato(int[] visao, int[] destArray) {
		if (destArray == cimaArr) {
			return verificaNaoPodeIr(visao[7]);
		}
		if (destArray == baixoArr) {
			return verificaNaoPodeIr(visao[16]);
		}
		if (destArray == esquerdaArr) {
			return verificaNaoPodeIr(visao[11]);
		}
		if (destArray == direitaArr) {
			return verificaNaoPodeIr(visao[12]);
		}
		return 0;
	}

	private int verificaNaoPodeIr(int i) {
		if (i == -2 || i == -1 || i == 1 || i == 4 || i == 5 || i >= 200) {
			return 100;
		}
		return 0;
	}

	private boolean verificaPodeIr(int val) {
		return verificaNaoPodeIr(val) == 0;
	}

	private void imprimiVisao(int[] visao) {
		int cont = 0;

		for (int i = 0; i < visao.length; i++) {

			if (cont % 5 == 0) {
				System.out.println();
			}
			if (i == 12) {
				System.out.print("  ");
				System.out.print("*" + visao[i]);
				cont++;
				cont++;
			} else {
				System.out.print("*" + visao[i]);
				cont++;
			}
		}
		System.out.println();
		System.out.println("=========================");
	}

	public int selecionaIntervalo(int[] visao, int intervalo1, int intervalo2) {
		int pos = (int) (intervalo1 + Math.random()
				* (intervalo2 - intervalo1 + 1));
		if (ultMovimento != 0) {
			pos = ultMovimento;
		}
		boolean moviMentoValido = false;
		int cont = 0;
		while (!moviMentoValido) {
			cont++;
			if (cont > 10) {
				break;
			}
			switch (pos) {
			case 1:
				if (verificaPodeIr(visao[7])) {
					moviMentoValido = true;
				}
				break;
			case 2:
				if (verificaPodeIr(visao[16])) {
					moviMentoValido = true;
				}
				break;
			case 3:
				if (verificaPodeIr(visao[12])) {
					moviMentoValido = true;
				}
				break;
			case 4:
				if (verificaPodeIr(visao[11])) {
					moviMentoValido = true;
				}
				break;
			default:
				break;
			}
			if (moviMentoValido) {
				if (verificaNoMuitoVisitado(pos)) {
					moviMentoValido = false;
				}
			}
			if (!moviMentoValido) {
				pos = (int) (intervalo1 + Math.random()
						* (intervalo2 - intervalo1 + 1));
			}
		}
		ultMovimento = pos;
		return pos;
	}

	private boolean verificaNoMuitoVisitado(int pos) {
		Point irPara;
		Integer val;
		switch (pos) {
		case 1:
			irPara = new Point(ultPonto.x, ultPonto.y + 1);
			val = obterValVisitado(irPara);
			if (val.intValue() > indexMuitoVisitado) {
				mapaNosVisitados.put(irPara, new Integer(1));
				return true;
			}
			break;
		case 2:
			irPara = new Point(ultPonto.x, ultPonto.y - 1);
			val = obterValVisitado(irPara);
			if (val.intValue() > indexMuitoVisitado) {
				mapaNosVisitados.put(irPara, new Integer(1));
				return true;
			}
			break;
		case 3:
			irPara = new Point(ultPonto.x + 1, ultPonto.y);
			val = obterValVisitado(irPara);
			if (val.intValue() > indexMuitoVisitado) {
				mapaNosVisitados.put(irPara, new Integer(1));
				return true;
			}
			break;
		case 4:
			irPara = new Point(ultPonto.x - 1, ultPonto.y);
			val = obterValVisitado(irPara);
			if (val.intValue() > indexMuitoVisitado) {
				mapaNosVisitados.put(irPara, new Integer(1));
				return true;
			}
			break;
		default:
			break;
		}
		return false;
	}

	private Integer obterValVisitado(Point irPara) {
		Integer integer = (Integer) mapaNosVisitados.get(irPara);
		if (integer != null) {
			return integer;
		}
		return new Integer(0);
	}

	public static void main(String[] args) {
		Ladrao ladrao = new Ladrao();
		// System.out.println(ladrao.selecionaIntervalo(0, 4));
	}
}
