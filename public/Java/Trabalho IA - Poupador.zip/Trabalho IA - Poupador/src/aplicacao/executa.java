package aplicacao;

import gui.FramePrincipal;

public class executa {

	public static void main(String[] args) {
		FramePrincipal jogo = new FramePrincipal();
		jogo.iniciarJogo();
	}
}
