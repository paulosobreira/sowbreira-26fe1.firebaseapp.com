package com.sun.java.swing.plaf.windows;

public class WindowsLookAndFeel extends javax.swing.plaf.metal.MetalLookAndFeel {

	private static final long serialVersionUID = 1L;

}
