# jmemoria
Jogo da memoria com cartas
Compile na IDE e execute:  java -cp .:lib/* br.nnpe.memoria.MemoriaMain
